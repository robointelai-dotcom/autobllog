<?php
/**
 * Plugin Name: Robointel AutoBlog Remote Bridge
 * Description: Secure REST bridge for the SEM SEO BLOGER / Gemini auto-poster. Provides ping, run, queue and status endpoints for the remote dashboard.
 * Version: 1.2.0
 * Author: robointel
 */
if ( ! defined('ABSPATH') ) { exit; }

define('GRB_BRIDGE_VER','1.2.0');

register_activation_hook(__FILE__, function(){
  if ( false === get_option('grb_api_key', false) ) {
    add_option('grb_api_key', wp_generate_password(32, false, false), '', false);
  }
});

add_action('admin_menu', function(){
  add_menu_page('AutoBlog Bridge','AutoBlog Bridge','manage_options','grb-bridge','grb_settings_page','dashicons-rest-api', 82);
});

add_action('admin_init', function(){
  register_setting('grb_bridge','grb_api_key', array(
    'type' => 'string',
    'sanitize_callback' => 'sanitize_text_field',
    'default' => ''
  ));
});

function grb_settings_page(){
  if ( ! current_user_can('manage_options') ) { return; }
  $key = get_option('grb_api_key','');
  ?>
  <div class="wrap">
    <h1>AutoBlog Remote Bridge</h1>
    <?php if ( ! function_exists('ppai_run_auto_post') ): ?>
      <div class="notice notice-error"><p><strong>Warning:</strong> SEM SEO BLOGER is not active. The dashboard can ping this bridge, but posting cannot run.</p></div>
    <?php endif; ?>
    <div class="notice notice-info"><p>Copy this API key into the remote dashboard site settings. Keep it private.</p></div>
    <form method="post" action="options.php">
      <?php settings_fields('grb_bridge'); do_settings_sections('grb_bridge'); ?>
      <table class="form-table" role="presentation">
        <tr><th scope="row"><label for="grb_api_key">Bridge API Key</label></th>
          <td><input name="grb_api_key" id="grb_api_key" type="text" class="regular-text" value="<?php echo esc_attr( $key ); ?>" autocomplete="off" /></td></tr>
      </table>
      <?php submit_button(); ?>
    </form>
    <h2>Endpoint Base</h2>
    <code><?php echo esc_html( home_url('/wp-json/grb/v1') ); ?></code>
    <p>Routes: <code>/ping</code>, <code>/run</code>, <code>/queue</code>, <code>/queue/sync</code>, <code>/queue/append</code>, <code>/queue/clear</code>, <code>/status</code></p>
  </div>
  <?php
}

class GRB_Bridge_Rest {
  private static function check_key( $request ){
    $hdr = (string) $request->get_header('x-api-key');
    $key = (string) get_option('grb_api_key','');
    if ( $key === '' || $hdr === '' ) { return false; }
    return function_exists('hash_equals') ? hash_equals($key, $hdr) : $key === $hdr;
  }

  private static function auth_or_error( $request ){
    if ( self::check_key($request) ) { return true; }
    return new WP_Error('grb_unauthorized','Unauthorized', array('status'=>401));
  }

  private static function queue(){
    $queue = get_option('ppai_csv_queue', array());
    return is_array($queue) ? array_values($queue) : array();
  }

  private static function sanitize_row( $row ){
    $keyword = isset($row['Keyword']) ? sanitize_text_field($row['Keyword']) : '';
    $topic = isset($row['Topic']) ? sanitize_text_field($row['Topic']) : '';
    $category = isset($row['Category']) ? sanitize_text_field($row['Category']) : '';
    $tags = isset($row['Tags']) ? sanitize_text_field($row['Tags']) : '';
    $image = '';
    if ( isset($row['image']) ) { $image = esc_url_raw($row['image']); }
    elseif ( isset($row['Image']) ) { $image = esc_url_raw($row['Image']); }
    elseif ( isset($row['image_url']) ) { $image = esc_url_raw($row['image_url']); }
    $backlink = '';
    if ( isset($row['Backlink']) ) { $backlink = esc_url_raw($row['Backlink']); }
    elseif ( isset($row['BacklinkURL']) ) { $backlink = esc_url_raw($row['BacklinkURL']); }
    elseif ( isset($row['backlink_url']) ) { $backlink = esc_url_raw($row['backlink_url']); }
    return array(
      'Keyword'  => $keyword,
      'Topic'    => $topic,
      'Category' => $category,
      'Tags'     => $tags,
      'image'    => $image,
      'Backlink' => $backlink,
    );
  }


  private static function row_key( $row ){
    $kw = isset($row['Keyword']) ? (string) $row['Keyword'] : '';
    $kw = wp_strip_all_tags($kw);
    $kw = preg_replace('/\\s+/u', ' ', trim($kw));
    return function_exists('mb_strtolower') ? mb_strtolower($kw, 'UTF-8') : strtolower($kw);
  }

  private static function published_keys(){
    $keys = array();
    $history = get_option('ppai_post_history', array());
    if ( is_array($history) ) {
      foreach ($history as $entry) {
        if ( ! empty($entry['keyword']) ) {
          $k = function_exists('mb_strtolower') ? mb_strtolower(trim(wp_strip_all_tags($entry['keyword'])), 'UTF-8') : strtolower(trim(wp_strip_all_tags($entry['keyword'])));
          if ( $k !== '' ) { $keys[$k] = true; }
        }
      }
    }
    $posts = get_posts(array(
      'post_type' => 'post',
      'post_status' => array('publish','draft','pending','future'),
      'posts_per_page' => 1000,
      'fields' => 'ids',
      'meta_query' => array(array('key'=>'rank_math_focus_keyword','compare'=>'EXISTS')),
      'no_found_rows' => true,
    ));
    foreach ($posts as $post_id) {
      $kw = get_post_meta($post_id, 'rank_math_focus_keyword', true);
      $kw = function_exists('mb_strtolower') ? mb_strtolower(trim(wp_strip_all_tags($kw)), 'UTF-8') : strtolower(trim(wp_strip_all_tags($kw)));
      if ( $kw !== '' ) { $keys[$kw] = true; }
    }
    return $keys;
  }

  private static function sync_queue( $items, $mode = 'smart', $skip_published = true ){
    $allowed = array('smart','append','replace','mirror');
    $mode = in_array($mode, $allowed, true) ? $mode : 'smart';
    $items = is_array($items) ? $items : array();
    if ( count($items) > 5000 ) { return new WP_Error('grb_too_many_rows','Max 5000 rows per request', array('status'=>413)); }

    $stats = array('mode'=>$mode,'received'=>count($items),'accepted'=>0,'added'=>0,'updated'=>0,'removed'=>0,'invalid'=>0,'duplicatesInCsv'=>0,'duplicatesInQueue'=>0,'skippedPublished'=>0,'queueCount'=>0);
    $deduped = array(); $order = array();
    foreach ($items as $row){
      if ( ! is_array($row) ) { $stats['invalid']++; continue; }
      $row = self::sanitize_row($row);
      $key = self::row_key($row);
      if ( $key === '' ) { $stats['invalid']++; continue; }
      if ( isset($deduped[$key]) ) { $stats['duplicatesInCsv']++; }
      else { $order[] = $key; }
      $deduped[$key] = $row;
    }

    $queue = array(); $index = array();
    foreach ( self::queue() as $row ){
      $row = self::sanitize_row(is_array($row) ? $row : array());
      $key = self::row_key($row);
      if ( $key === '' ) { continue; }
      if ( isset($index[$key]) ) { $stats['duplicatesInQueue']++; continue; }
      $index[$key] = count($queue);
      $queue[] = $row;
    }

    $published = $skip_published ? self::published_keys() : array();
    $new_queue = $queue;
    if ( $mode === 'replace' || $mode === 'mirror' ){
      $new_queue = array();
      foreach ($order as $key){
        if ( $skip_published && isset($published[$key]) ) { $stats['skippedPublished']++; continue; }
        $new_queue[] = $deduped[$key]; $stats['added']++;
      }
      $stats['removed'] = max(0, count($queue) - count($new_queue));
    } elseif ( $mode === 'append' ){
      foreach ($order as $key){
        if ( isset($index[$key]) ) { continue; }
        if ( $skip_published && isset($published[$key]) ) { $stats['skippedPublished']++; continue; }
        $new_queue[] = $deduped[$key]; $index[$key] = count($new_queue)-1; $stats['added']++;
      }
    } else {
      foreach ($order as $key){
        if ( isset($index[$key]) ) { $new_queue[$index[$key]] = $deduped[$key]; $stats['updated']++; continue; }
        if ( $skip_published && isset($published[$key]) ) { $stats['skippedPublished']++; continue; }
        $new_queue[] = $deduped[$key]; $index[$key] = count($new_queue)-1; $stats['added']++;
      }
    }
    $stats['accepted'] = $stats['added'] + $stats['updated'];
    $stats['queueCount'] = count($new_queue);
    update_option('ppai_csv_queue', array_values($new_queue), false);
    update_option('ppai_last_csv_sync', array_merge($stats, array('time'=>current_time('mysql'))), false);
    return $stats;
  }

  public static function register(){
    register_rest_route('grb/v1','/ping', array(
      'methods' => array('GET','POST'),
      'permission_callback' => '__return_true',
      'callback' => function($req){
        $auth = self::auth_or_error($req); if ( is_wp_error($auth) ) { return $auth; }
        return array('ok'=>true,'bridgeVersion'=>GRB_BRIDGE_VER,'pluginActive'=>function_exists('ppai_run_auto_post'),'site'=>home_url());
      }
    ));

    register_rest_route('grb/v1','/status', array(
      'methods' => 'GET',
      'permission_callback' => '__return_true',
      'callback' => function($req){
        $auth = self::auth_or_error($req); if ( is_wp_error($auth) ) { return $auth; }
        $history = get_option('ppai_post_history', array());
        if ( ! is_array($history) ) { $history = array(); }
        $history = array_slice($history, -50);
        return array(
          'ok' => true,
          'queueCount'=> count(self::queue()),
          'lastError'=> get_option('ppai_last_error', ''),
          'history'=> array_values($history),
          'cronEnabled'=> (bool) wp_next_scheduled('ppai_auto_post_event')
        );
      }
    ));

    register_rest_route('grb/v1','/run', array(
      'methods' => 'POST',
      'permission_callback' => '__return_true',
      'callback' => function($req){
        $auth = self::auth_or_error($req); if ( is_wp_error($auth) ) { return $auth; }
        if ( ! function_exists('ppai_run_auto_post') ) { return new WP_Error('grb_missing','SEM SEO BLOGER plugin not active', array('status'=>500)); }
        ob_start();
        $res = ppai_run_auto_post();
        $echo = ob_get_clean();
        if ( is_wp_error($res) ) {
          return new WP_Error('grb_run_failed', $res->get_error_message(), array('status'=>500));
        }
        $history = get_option('ppai_post_history', array());
        $last = is_array($history) && count($history) ? end($history) : null;
        return array('ok'=>true,'message'=>'Run completed','result'=>$res,'historyLast'=>$last,'echo'=>$echo,'queueCount'=>count(self::queue()));
      }
    ));

    register_rest_route('grb/v1','/queue', array(
      'methods' => 'GET',
      'permission_callback' => '__return_true',
      'callback' => function($req){
        $auth = self::auth_or_error($req); if ( is_wp_error($auth) ) { return $auth; }
        return array('ok'=>true,'items'=> self::queue());
      }
    ));


    register_rest_route('grb/v1','/queue/sync', array(
      'methods' => 'POST',
      'permission_callback' => '__return_true',
      'callback' => function($req){
        $auth = self::auth_or_error($req); if ( is_wp_error($auth) ) { return $auth; }
        $p = $req->get_json_params();
        $items = isset($p['items']) && is_array($p['items']) ? $p['items'] : array();
        $mode = isset($p['mode']) ? sanitize_key($p['mode']) : 'smart';
        $skip = array_key_exists('skipPublished', $p) ? (bool) $p['skipPublished'] : true;
        $sync = self::sync_queue($items, $mode, $skip);
        if ( is_wp_error($sync) ) { return $sync; }
        return array_merge(array('ok'=>true), $sync);
      }
    ));

    register_rest_route('grb/v1','/queue/append', array(
      'methods' => 'POST',
      'permission_callback' => '__return_true',
      'callback' => function($req){
        $auth = self::auth_or_error($req); if ( is_wp_error($auth) ) { return $auth; }
        $p = $req->get_json_params();
        $items = isset($p['items']) && is_array($p['items']) ? $p['items'] : array();
        if ( count($items) > 5000 ) { return new WP_Error('grb_too_many_rows','Max 5000 rows per request', array('status'=>413)); }
        $sync = self::sync_queue($items, 'append', true);
        if ( is_wp_error($sync) ) { return $sync; }
        return array_merge(array('ok'=>true), $sync);
      }
    ));

    register_rest_route('grb/v1','/queue/clear', array(
      'methods' => 'POST',
      'permission_callback' => '__return_true',
      'callback' => function($req){
        $auth = self::auth_or_error($req); if ( is_wp_error($auth) ) { return $auth; }
        update_option('ppai_csv_queue', array(), false);
        return array('ok'=>true,'queueCount'=>0);
      }
    ));
  }
}
add_action('rest_api_init', array('GRB_Bridge_Rest','register'));

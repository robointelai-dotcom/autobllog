<?php
if (!defined('ABSPATH')) exit;

function ppai_text_length($value) {
    $value = (string) $value;
    return function_exists('mb_strlen') ? mb_strlen($value, 'UTF-8') : strlen($value);
}

function ppai_text_substr($value, $start, $length = null) {
    $value = (string) $value;
    if (function_exists('mb_substr')) {
        return $length === null ? mb_substr($value, $start, null, 'UTF-8') : mb_substr($value, $start, $length, 'UTF-8');
    }
    return $length === null ? substr($value, $start) : substr($value, $start, $length);
}

function ppai_redact_secret_text($value, $max_length = 1200) {
    $value = (string) $value;
    $value = preg_replace('/((?:[?&]|\b)(?:key|api_key|apikey|geminiApiKey|bridgeApiKey|token|access_token|secret|password)=)[^&\s,;]*/i', '$1[REDACTED]', $value);
    $value = preg_replace('/(["\'](?:key|api[_-]?key|apikey|geminiApiKey|bridgeApiKey|token|access[_-]?token|secret|password)["\']\s*:\s*["\'])[^"\']*(["\'])/i', '$1[REDACTED]$2', $value);
    return ppai_text_substr($value, 0, max(100, (int) $max_length));
}

function ppai_extract_gemini_text($data) {
    if (!isset($data['candidates'][0]['content']['parts']) || !is_array($data['candidates'][0]['content']['parts'])) return '';
    $parts = array();
    foreach ($data['candidates'][0]['content']['parts'] as $part) {
        if (isset($part['text']) && is_string($part['text'])) $parts[] = $part['text'];
    }
    return trim(implode("\n", $parts));
}

function ppai_default_prompt($topic, $keyword) {
    return "You are an expert SEO blog writer and careful content editor.\n\n" .
        "Write a complete, useful, search-intent-focused article for a general audience on the topic \"{$topic}\". Use the primary keyword \"{$keyword}\" naturally in the title, introduction, at least one subheading, and conclusion. Do not keyword-stuff.\n\n" .
        "Target 1500+ words when the subject benefits from depth. Add practical steps, examples, benefits, mistakes to avoid, and decision guidance where relevant. Generate an SEO title around 50-60 characters and a meta description around 150-160 characters.\n\n" .
        "Strict accuracy and safety rules:\n" .
        "- Do not invent facts, statistics, prices, awards, testimonials, laws, medical claims, financial claims, or source names.\n" .
        "- If exact or current information is uncertain, use cautious wording and tell the reader to verify it with a qualified source.\n" .
        "- For financial, medical, legal, or other high-stakes topics, provide educational information only and no personalised advice, diagnosis, prescription, guarantee, or promise of results.\n" .
        "- Do not include harmful, illegal, deceptive, hateful, adult, or unsafe instructions.\n\n" .
        "Format the output in clean HTML only:\n" .
        "- Begin with one <p> containing only the meta description.\n" .
        "- Follow with one <h1> title.\n" .
        "- Then write the article using <h2>, <h3>, <p>, <ul>, <ol>, <li>, <strong>, <em>, <blockquote>, and simple table tags only when helpful.\n" .
        "- Include 4-6 useful FAQ questions near the end.\n" .
        "Do not use markdown, JSON, emojis, scripts, styles, fake data, or explanatory labels like Title: or Meta Description:.";
}

function ppai_apply_prompt_variables($prompt, $topic, $keyword, $backlink_url = '') {
    return strtr((string) $prompt, array(
        '$topic' => $topic, '{{topic}}' => $topic, '{topic}' => $topic,
        '$keyword' => $keyword, '{{keyword}}' => $keyword, '{keyword}' => $keyword,
        '$backlink' => esc_url_raw($backlink_url), '{{backlink}}' => esc_url_raw($backlink_url), '{backlink}' => esc_url_raw($backlink_url),
    ));
}

function ppai_build_generation_prompt($topic, $keyword, $backlink_url = '', $row_prompt = '') {
    $topic = sanitize_text_field($topic);
    $keyword = sanitize_text_field($keyword);
    $site_prompt = trim((string) get_option('ppai_custom_prompt', ''));
    $prompt = $site_prompt !== ''
        ? ppai_apply_prompt_variables($site_prompt, $topic, $keyword, $backlink_url)
        : ppai_default_prompt($topic, $keyword);

    $row_prompt = trim((string) $row_prompt);
    if ($row_prompt !== '') {
        $row_prompt = ppai_text_substr(wp_kses_post($row_prompt), 0, 5000);
        $row_prompt = ppai_apply_prompt_variables($row_prompt, $topic, $keyword, $backlink_url);
        $prompt .= "\n\nAdditional per-post instruction (follow only when it does not conflict with the base safety, accuracy, HTML, or compliance rules):\n" . $row_prompt;
    }

    $prompt .= "\n\nNon-negotiable final rules: return clean HTML only; no markdown/code fences/scripts/styles; do not invent facts or claims; do not provide personalised high-stakes advice; do not promise profit, returns, cures, legal outcomes, or guaranteed results; keep the requested topic and keyword intent accurate.";
    return $prompt;
}

function ppai_generate_article($topic, $keyword, $backlink_url = '', $row_prompt = '') {
    $api_key = trim((string) get_option('ppai_gamini_api_key', ''));
    if ($api_key === '') {
        return new WP_Error('ppai_missing_api_key', 'Gemini API key is missing.');
    }

    $topic = sanitize_text_field($topic);
    $keyword = sanitize_text_field($keyword);
    $prompt = ppai_build_generation_prompt($topic, $keyword, $backlink_url, $row_prompt);

    $model = function_exists('ppai_resolve_gemini_model')
        ? ppai_resolve_gemini_model(get_option('ppai_gemini_model', ''))
        : 'gemini-2.5-flash';
    $endpoint = 'https://generativelanguage.googleapis.com/v1beta/models/' . rawurlencode($model) . ':generateContent?key=' . rawurlencode($api_key);

    $body = wp_json_encode(array(
        'contents' => array(array('parts' => array(array('text' => $prompt)))),
        'generationConfig' => array(
            'temperature' => 0.55,
            'topP' => 0.9,
            'maxOutputTokens' => 8192,
        ),
    ));

    $response = wp_remote_post($endpoint, array(
        'headers' => array('Content-Type' => 'application/json'),
        'body' => $body,
        'timeout' => 150
    ));

    if (is_wp_error($response)) {
        return new WP_Error('ppai_connection_error', 'Gemini connection error: ' . ppai_redact_secret_text($response->get_error_message()));
    }

    $code = (int) wp_remote_retrieve_response_code($response);
    $json = wp_remote_retrieve_body($response);
    $data = json_decode($json, true);
    if ($code < 200 || $code >= 300) {
        $msg = isset($data['error']['message']) ? $data['error']['message'] : $json;
        return new WP_Error('ppai_gemini_http_error', 'Gemini HTTP ' . $code . ': ' . ppai_redact_secret_text($msg));
    }

    $text = ppai_extract_gemini_text($data);
    if ($text === '') {
        $error_msg = 'No content returned.';
        if (isset($data['promptFeedback']['blockReason'])) {
            $error_msg .= ' Prompt was blocked: ' . sanitize_text_field($data['promptFeedback']['blockReason']);
        } elseif (isset($data['candidates'][0]['finishReason'])) {
            $error_msg .= ' Finish reason: ' . sanitize_text_field($data['candidates'][0]['finishReason']);
        } elseif (isset($data['error']['message'])) {
            $error_msg .= ' Gemini error: ' . sanitize_text_field($data['error']['message']);
        }
        return new WP_Error('ppai_no_content', ppai_redact_secret_text($error_msg));
    }

    $text = ppai_clean_text($text);
    $parsed = ppai_extract_title_meta_content($text, $topic);
    $content_with_backlink = ppai_add_backlink($parsed['content'], $keyword, $backlink_url);

    return array(
        'title' => $parsed['title'],
        'content' => "<div class='blog-container'><p>" . esc_html($parsed['meta']) . "</p>" . $content_with_backlink . "</div>",
        'meta' => $parsed['meta']
    );
}

function ppai_clean_text($text) {
    $text = (string) $text;
    $text = preg_replace('/```(?:html)?/i', '', $text);
    $text = str_replace('```', '', $text);
    $text = preg_replace('/<script\b[^>]*>(.*?)<\/script>/is', '', $text);
    $text = preg_replace('/<style\b[^>]*>(.*?)<\/style>/is', '', $text);
    $text = preg_replace('/<img[^>]+>/i', '', $text);
    $text = preg_replace('/^\s*Blog Title:\s*/im', '', $text);
    $text = preg_replace('/^\s*Meta Description:\s*/im', '', $text);
    $text = preg_replace('/[\x{1F600}-\x{1F64F}\x{1F300}-\x{1F5FF}\x{1F680}-\x{1F6FF}\x{2600}-\x{26FF}]/u', '', $text);
    // Do not delete *, #, _ or ~ globally; those can be legitimate text or URLs.
    return trim($text);
}

function ppai_extract_title_meta_content($html, $fallback_topic) {
    $html = trim($html);
    $meta = '';
    if (preg_match('/<p\b[^>]*>(.*?)<\/p>/is', $html, $m)) {
        $meta = trim(wp_strip_all_tags($m[1]));
        $html = preg_replace('/<p\b[^>]*>.*?<\/p>/is', '', $html, 1);
    }
    if ($meta === '') $meta = ppai_text_substr(wp_strip_all_tags($html), 0, 155);
    if (ppai_text_length($meta) > 160) $meta = ppai_text_substr($meta, 0, 157) . '...';

    $title = ucfirst($fallback_topic);
    if (preg_match('/<h1\b[^>]*>(.*?)<\/h1>/is', $html, $m)) {
        $title = trim(wp_strip_all_tags($m[1]));
        $html = preg_replace('/<h1\b[^>]*>.*?<\/h1>/is', '', $html, 1);
    }
    $title = sanitize_text_field($title ?: ucfirst($fallback_topic));

    $allowed = array(
        'h1'=>array(), 'h2'=>array(), 'h3'=>array(), 'h4'=>array(),
        'p'=>array(), 'ul'=>array(), 'ol'=>array(), 'li'=>array(),
        'strong'=>array(), 'b'=>array(), 'em'=>array(), 'i'=>array(),
        'a'=>array('href'=>array(),'target'=>array(),'rel'=>array()),
        'br'=>array(), 'blockquote'=>array(),
        'table'=>array(), 'thead'=>array(), 'tbody'=>array(), 'tfoot'=>array(),
        'tr'=>array(), 'th'=>array('scope'=>array(), 'colspan'=>array(), 'rowspan'=>array()),
        'td'=>array('colspan'=>array(), 'rowspan'=>array())
    );
    $html = wp_kses($html, $allowed);
    return array('title'=>$title, 'meta'=>sanitize_text_field($meta), 'content'=>$html);
}

function ppai_add_backlink($html, $keyword, $backlink_url) {
    $backlink_url = esc_url($backlink_url);
    $keyword = sanitize_text_field($keyword);
    if ($backlink_url === '' || $keyword === '') return $html;

    // Respect a link already included by the model/custom prompt.
    if (stripos($html, $backlink_url) !== false) return $html;

    $anchor = '<a href="' . esc_url($backlink_url) . '" target="_blank" rel="noopener">' . esc_html($keyword) . '</a>';
    $pattern = '/(?<![\p{L}\p{N}_])(' . preg_quote($keyword, '/') . ')(?![\p{L}\p{N}_])/iu';

    // Split HTML into tags and text. Only replace visible text outside an
    // existing <a> element, never inside attributes or nested links.
    $parts = preg_split('/(<[^>]+>)/u', $html, -1, PREG_SPLIT_DELIM_CAPTURE);
    if (is_array($parts)) {
        $inside_anchor = 0;
        foreach ($parts as $i => $part) {
            if ($part === '') continue;
            if ($part[0] === '<') {
                if (preg_match('/^<a\b/i', $part)) $inside_anchor++;
                elseif (preg_match('/^<\/a\b/i', $part) && $inside_anchor > 0) $inside_anchor--;
                continue;
            }
            if ($inside_anchor === 0 && preg_match($pattern, $part)) {
                $parts[$i] = preg_replace($pattern, $anchor, $part, 1);
                return implode('', $parts);
            }
        }
    }

    if (preg_match_all('/(<p\b[^>]*>.*?<\/p>)/is', $html, $paragraphs) && !empty($paragraphs[0])) {
        $middle = (int) floor(count($paragraphs[0]) / 2);
        $target = $paragraphs[0][$middle];
        $replacement = preg_replace('/<\/p>$/i', ' ' . $anchor . '</p>', $target);
        return preg_replace('/' . preg_quote($target, '/') . '/s', $replacement, $html, 1);
    }

    return $html . '<p>' . $anchor . '</p>';
}

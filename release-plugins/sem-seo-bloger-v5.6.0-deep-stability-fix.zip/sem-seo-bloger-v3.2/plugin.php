<?php
/*
Plugin Name: SEM SEO BLOGER
Description: Gemini-powered SEO blog generator with CSV queue, safe manual generation, and remote bridge support.
Version: 5.6.0
Author: seo seo manager
*/
if (!defined('ABSPATH')) exit;

define('PPAI_PLUGIN_PATH', plugin_dir_path(__FILE__));
define('PPAI_PLUGIN_VER', '5.6.0');
define('PPAI_DEFAULT_GEMINI_MODEL', 'gemini-2.5-flash');

function ppai_media_runtime_includes() {
    if (!function_exists('download_url') || !function_exists('wp_handle_sideload')) {
        require_once ABSPATH . 'wp-admin/includes/file.php';
    }
    if (!function_exists('wp_insert_attachment')) {
        require_once ABSPATH . 'wp-admin/includes/media.php';
    }
    if (!function_exists('wp_generate_attachment_metadata')) {
        require_once ABSPATH . 'wp-admin/includes/image.php';
    }
}

include_once PPAI_PLUGIN_PATH . 'includes/csv-parser.php';
include_once PPAI_PLUGIN_PATH . 'includes/gamini-api.php';
include_once PPAI_PLUGIN_PATH . 'includes/admin-ui.php';

function ppai_default_gemini_model() {
    return defined('PPAI_DEFAULT_GEMINI_MODEL') ? PPAI_DEFAULT_GEMINI_MODEL : 'gemini-2.5-flash';
}

function ppai_resolve_gemini_model($model = '') {
    $model = function_exists('ppai_text_substr') ? ppai_text_substr(sanitize_text_field((string) $model), 0, 120) : substr(sanitize_text_field((string) $model), 0, 120);
    $retired_defaults = array('gemini-2.0-flash', 'gemini-2.0-flash-001', 'gemini-2.0-flash-lite', 'gemini-2.0-flash-lite-001');
    if ($model === '' || in_array(strtolower($model), $retired_defaults, true)) {
        return ppai_default_gemini_model();
    }
    return $model;
}

function ppai_maybe_migrate_gemini_model() {
    $stored = (string) get_option('ppai_gemini_model', '');
    $resolved = ppai_resolve_gemini_model($stored);
    if ($stored !== $resolved) {
        update_option('ppai_gemini_model', $resolved, false);
    }
    return $resolved;
}
add_action('init', 'ppai_maybe_migrate_gemini_model', 1);

function ppai_custom_cron_interval($schedules) {
    $schedules['every_4_minutes'] = array(
        'interval' => 240,
        'display' => __('Every 4 Minutes', 'ppai')
    );
    return $schedules;
}
add_filter('cron_schedules', 'ppai_custom_cron_interval');

function ppai_schedule_cron_if_enabled() {
    if (get_option('ppai_enable_cron', false)) {
        if (!wp_next_scheduled('ppai_auto_post_event')) {
            wp_schedule_event(time() + 60, 'every_4_minutes', 'ppai_auto_post_event');
        }
    } else {
        if (wp_next_scheduled('ppai_auto_post_event')) {
            wp_clear_scheduled_hook('ppai_auto_post_event');
        }
    }
}

function ppai_run_lock_option_name() {
    return 'ppai_run_lock_atomic';
}

function ppai_acquire_run_lock($ttl = 600) {
    $ttl = max(60, (int) $ttl);
    $name = ppai_run_lock_option_name();
    $now = time();
    $token = function_exists('wp_generate_uuid4') ? wp_generate_uuid4() : uniqid('ppai_run_', true);
    $payload = array('token'=>$token, 'created'=>$now, 'expires'=>$now + $ttl);
    if (add_option($name, $payload, '', 'no')) return $token;

    $existing = get_option($name, array());
    $expires = is_array($existing) ? (int) ($existing['expires'] ?? 0) : 0;
    if ($expires > 0 && $expires < $now) {
        delete_option($name);
        if (add_option($name, $payload, '', 'no')) return $token;
    }
    return false;
}

function ppai_release_run_lock($token = null) {
    $name = ppai_run_lock_option_name();
    if ($token === null) {
        // Force cleanup is used only on plugin deactivation/migration.
        delete_option($name);
    } else {
        $existing = get_option($name, array());
        if (is_array($existing) && isset($existing['token']) && hash_equals((string)$existing['token'], (string)$token)) {
            delete_option($name);
        }
    }
    delete_transient('ppai_run_lock'); // remove legacy v5.5 lock if present
}


function ppai_queue_lock_option_name() {
    return 'ppai_queue_lock_atomic';
}

function ppai_acquire_queue_lock($ttl = 60) {
    $ttl = max(15, (int) $ttl);
    $name = ppai_queue_lock_option_name();
    $now = time();
    $token = function_exists('wp_generate_uuid4') ? wp_generate_uuid4() : uniqid('ppai_queue_', true);
    $payload = array('token'=>$token, 'created'=>$now, 'expires'=>$now + $ttl);
    if (add_option($name, $payload, '', 'no')) return $token;
    $existing = get_option($name, array());
    $expires = is_array($existing) ? (int) ($existing['expires'] ?? 0) : 0;
    if ($expires > 0 && $expires < $now) {
        delete_option($name);
        if (add_option($name, $payload, '', 'no')) return $token;
    }
    return false;
}

function ppai_release_queue_lock($token) {
    $existing = get_option(ppai_queue_lock_option_name(), array());
    if (is_array($existing) && isset($existing['token']) && hash_equals((string)$existing['token'], (string)$token)) {
        delete_option(ppai_queue_lock_option_name());
    }
}

function ppai_deactivate_plugin() {
    wp_clear_scheduled_hook('ppai_auto_post_event');
    ppai_release_run_lock();
    delete_option(ppai_queue_lock_option_name());
}

function ppai_activate_plugin() {
    ppai_maybe_migrate_gemini_model();
    ppai_schedule_cron_if_enabled();
}
register_activation_hook(__FILE__, 'ppai_activate_plugin');
register_deactivation_hook(__FILE__, 'ppai_deactivate_plugin');
add_action('ppai_auto_post_event', 'ppai_run_auto_post');
add_action('init', 'ppai_schedule_cron_if_enabled');

add_action('admin_init', function() {
    register_setting('ppai-settings-group', 'ppai_gamini_api_key', array('sanitize_callback'=>'sanitize_text_field'));
    register_setting('ppai-settings-group', 'ppai_custom_prompt', array('sanitize_callback'=>'wp_kses_post'));
    register_setting('ppai-settings-group', 'ppai_gemini_model', array('sanitize_callback'=>'sanitize_text_field'));
});

add_action('wp_ajax_ppai_run_manual_post', function(){
    if (!current_user_can('manage_options')) {
        wp_send_json_error(array('message'=>'Permission denied'), 403);
    }
    check_ajax_referer('ppai_manual_run', 'nonce');
    $result = ppai_run_auto_post();
    if (is_wp_error($result)) {
        wp_send_json_error(array('message'=>$result->get_error_message()), 500);
    }
    wp_send_json_success($result);
});

function ppai_normalize_queue_row($row) {
    $row = is_array($row) ? $row : array();
    $keyword = isset($row['Keyword']) ? sanitize_text_field($row['Keyword']) : '';
    $topic = isset($row['Topic']) && $row['Topic'] !== '' ? sanitize_text_field($row['Topic']) : $keyword;
    $category = isset($row['Category']) && $row['Category'] !== '' ? sanitize_text_field($row['Category']) : 'Uncategorized';
    $tags_raw = isset($row['Tags']) ? sanitize_text_field($row['Tags']) : '';
    $image = '';
    if (!empty($row['image'])) $image = esc_url_raw($row['image']);
    elseif (!empty($row['Image'])) $image = esc_url_raw($row['Image']);
    elseif (!empty($row['image_url'])) $image = esc_url_raw($row['image_url']);
    $backlink = '';
    if (!empty($row['Backlink'])) $backlink = esc_url_raw($row['Backlink']);
    elseif (!empty($row['BacklinkURL'])) $backlink = esc_url_raw($row['BacklinkURL']);
    elseif (!empty($row['backlink_url'])) $backlink = esc_url_raw($row['backlink_url']);
    $prompt = '';
    if (!empty($row['Prompt'])) $prompt = wp_kses_post((string) $row['Prompt']);
    elseif (!empty($row['CustomPrompt'])) $prompt = wp_kses_post((string) $row['CustomPrompt']);
    elseif (!empty($row['custom_prompt'])) $prompt = wp_kses_post((string) $row['custom_prompt']);
    elseif (!empty($row['PostPrompt'])) $prompt = wp_kses_post((string) $row['PostPrompt']);
    if (ppai_text_length($prompt) > 5000) $prompt = ppai_text_substr($prompt, 0, 5000);

    $tags = array_filter(array_map('trim', explode(',', $tags_raw)));
    return compact('keyword','topic','category','tags','image','backlink','prompt');
}

function ppai_get_or_create_category_id($category_name) {
    $category_name = sanitize_text_field($category_name ? $category_name : 'Uncategorized');
    if ($category_name === '') $category_name = 'Uncategorized';

    // The legacy admin-only category helper is not loaded during REST/cron
    // requests. These taxonomy functions work in normal runtime.
    $existing = term_exists($category_name, 'category');
    if (is_array($existing) && !empty($existing['term_id'])) return (int) $existing['term_id'];
    if (is_numeric($existing) && (int) $existing > 0) return (int) $existing;

    $created = wp_insert_term($category_name, 'category');
    if (is_wp_error($created)) {
        // Another request may have created the category at the same moment.
        if ($created->get_error_code() === 'term_exists') {
            $term_id = (int) $created->get_error_data('term_exists');
            if ($term_id > 0) return $term_id;
        }
        return $created;
    }
    return isset($created['term_id'])
        ? (int) $created['term_id']
        : new WP_Error('ppai_category_failed', 'WordPress did not return a category ID.');
}

function ppai_default_author_id() {
    $current = (int) get_current_user_id();
    if ($current > 0 && get_userdata($current)) return $current;

    $configured = (int) get_option('ppai_default_author_id', 0);
    if ($configured > 0 && get_userdata($configured)) return $configured;

    $users = get_users(array(
        'role__in' => array('administrator', 'editor', 'author'),
        'number'   => 1,
        'fields'   => 'ID',
        'orderby'  => 'ID',
        'order'    => 'ASC',
    ));
    if (!empty($users)) return (int) $users[0];

    $fallback_users = get_users(array('number'=>1, 'fields'=>'ID', 'orderby'=>'ID', 'order'=>'ASC'));
    return !empty($fallback_users) ? (int) $fallback_users[0] : 0;
}

function ppai_attach_featured_image($post_id, $image_url) {
    if (empty($image_url)) return 0;
    ppai_media_runtime_includes();
    $tmp = download_url($image_url, 30);
    if (is_wp_error($tmp)) return $tmp;

    $path = parse_url($image_url, PHP_URL_PATH);
    $name = $path ? basename($path) : ('featured-' . time() . '.jpg');
    if (!$name || $name === '/') $name = 'featured-' . time() . '.jpg';

    $file_array = array('name' => sanitize_file_name($name), 'tmp_name' => $tmp);
    $file = wp_handle_sideload($file_array, array('test_form' => false));
    if (isset($file['error'])) {
        @unlink($tmp);
        return new WP_Error('ppai_image_error', $file['error']);
    }

    $attachment = array(
        'post_mime_type' => $file['type'],
        'post_title'     => sanitize_file_name(pathinfo($file['file'], PATHINFO_FILENAME)),
        'post_content'   => '',
        'post_status'    => 'inherit'
    );
    $attach_id = wp_insert_attachment($attachment, $file['file'], $post_id);
    if (is_wp_error($attach_id)) {
        @unlink($file['file']);
        return $attach_id;
    }

    $attach_data = wp_generate_attachment_metadata($attach_id, $file['file']);
    if (is_wp_error($attach_data)) {
        wp_delete_attachment($attach_id, true);
        return $attach_data;
    }
    if (is_array($attach_data)) wp_update_attachment_metadata($attach_id, $attach_data);
    if (!set_post_thumbnail($post_id, $attach_id)) {
        wp_delete_attachment($attach_id, true);
        return new WP_Error('ppai_thumbnail_failed', 'WordPress could not assign the featured image.');
    }
    return $attach_id;
}

function ppai_history_add($entry) {
    $history = get_option('ppai_post_history', array());
    if (!is_array($history)) $history = array();
    $history[] = $entry;
    if (count($history) > 500) $history = array_slice($history, -500);
    update_option('ppai_post_history', $history, false);
}


function ppai_queue_key_from_keyword($keyword) {
    $keyword = is_string($keyword) ? $keyword : '';
    $keyword = wp_strip_all_tags($keyword);
    $keyword = preg_replace('/\s+/u', ' ', trim($keyword));
    if (function_exists('mb_strtolower')) return mb_strtolower($keyword, 'UTF-8');
    return strtolower($keyword);
}

function ppai_queue_row_key($row) {
    $row = ppai_normalize_queue_row(is_array($row) ? $row : array());
    return ppai_queue_key_from_keyword($row['keyword']);
}

function ppai_queue_canonical_row($row) {
    $row = ppai_normalize_queue_row(is_array($row) ? $row : array());
    $tags = is_array($row['tags']) ? implode(', ', array_map('sanitize_text_field', $row['tags'])) : sanitize_text_field((string) $row['tags']);
    return array(
        'Keyword'  => sanitize_text_field($row['keyword']),
        'Topic'    => sanitize_text_field($row['topic']),
        'Category' => sanitize_text_field($row['category']),
        'Tags'     => $tags,
        'image'    => esc_url_raw($row['image']),
        'Backlink' => esc_url_raw($row['backlink']),
        'Prompt'   => wp_kses_post($row['prompt']),
    );
}

function ppai_get_published_queue_keys() {
    $keys = array();
    $history = get_option('ppai_post_history', array());
    if (is_array($history)) {
        foreach ($history as $entry) {
            if (!empty($entry['keyword'])) {
                $k = ppai_queue_key_from_keyword($entry['keyword']);
                if ($k !== '') $keys[$k] = true;
            }
        }
    }

    $posts = get_posts(array(
        'post_type'      => 'post',
        'post_status'    => array('publish', 'draft', 'pending', 'future'),
        'posts_per_page' => 1000,
        'fields'         => 'ids',
        'meta_query'     => array(
            'relation' => 'OR',
            array('key' => 'rank_math_focus_keyword', 'compare' => 'EXISTS'),
            array('key' => '_ppai_queue_keyword', 'compare' => 'EXISTS')
        ),
        'no_found_rows'  => true,
    ));
    foreach ($posts as $post_id) {
        $kw = get_post_meta($post_id, 'rank_math_focus_keyword', true);
        if ($kw === '') $kw = get_post_meta($post_id, '_ppai_queue_keyword', true);
        $k = ppai_queue_key_from_keyword($kw);
        if ($k !== '') $keys[$k] = true;
    }
    return $keys;
}


function ppai_keyword_was_recently_published($keyword, $window_seconds = 3600) {
    $keyword = sanitize_text_field((string) $keyword);
    if ($keyword === '') return false;
    $window_seconds = max(300, min(DAY_IN_SECONDS, (int) $window_seconds));
    $recent = get_posts(array(
        'post_type'      => 'post',
        'post_status'    => array('publish', 'future'),
        'posts_per_page' => 1,
        'fields'         => 'ids',
        'meta_query'     => array(
            'relation' => 'OR',
            array('key' => '_ppai_queue_keyword', 'value' => $keyword, 'compare' => '='),
            array('key' => 'rank_math_focus_keyword', 'value' => $keyword, 'compare' => '='),
        ),
        'date_query'     => array(array(
            'column'    => 'post_date_gmt',
            'after'     => gmdate('Y-m-d H:i:s', time() - $window_seconds),
            'inclusive' => true,
        )),
        'no_found_rows'  => true,
    ));
    return !empty($recent);
}

function ppai_sync_csv_queue($incoming_rows, $mode = 'smart', $skip_published = false) {
    $incoming_rows = is_array($incoming_rows) ? $incoming_rows : array();
    if (count($incoming_rows) > 5000) {
        return new WP_Error('ppai_too_many_rows', 'Maximum 5000 queue rows per sync request.', array('status'=>413));
    }
    $queue_lock = ppai_acquire_queue_lock(5 * MINUTE_IN_SECONDS);
    if ($queue_lock === false) return new WP_Error('ppai_queue_busy', 'Queue sync is already running. Please retry in a moment.', array('status'=>409));
    try {
    $allowed = array('smart', 'append', 'replace', 'mirror');
    $mode = in_array($mode, $allowed, true) ? $mode : 'smart';
    $skip_published = (bool) $skip_published;

    $stats = array(
        'mode' => $mode,
        'received' => count($incoming_rows),
        'accepted' => 0,
        'added' => 0,
        'updated' => 0,
        'removed' => 0,
        'invalid' => 0,
        'duplicatesInCsv' => 0,
        'duplicatesInQueue' => 0,
        'skippedPublished' => 0,
        'queueCount' => 0,
    );

    $published = $skip_published ? ppai_get_published_queue_keys() : array();
    $skipped_keys = array();
    $mark_skipped = function($key) use (&$stats, &$skipped_keys) {
        if (!isset($skipped_keys[$key])) {
            $skipped_keys[$key] = true;
            $stats['skippedPublished']++;
        }
    };

    $deduped = array();
    $order = array();
    foreach ($incoming_rows as $row) {
        $row = ppai_queue_canonical_row($row);
        $key = ppai_queue_row_key($row);
        if ($key === '') { $stats['invalid']++; continue; }
        if (isset($deduped[$key])) { $stats['duplicatesInCsv']++; }
        else { $order[] = $key; }
        $deduped[$key] = $row; // latest CSV value wins for the same keyword
    }

    $current = get_option('ppai_csv_queue', array());
    if (!is_array($current)) $current = array();
    $queue = array();
    $index = array();
    $original_keys = array();
    foreach ($current as $row) {
        $row = ppai_queue_canonical_row($row);
        $key = ppai_queue_row_key($row);
        if ($key === '') continue;
        if (isset($original_keys[$key])) { $stats['duplicatesInQueue']++; continue; }
        $original_keys[$key] = true;
        if ($skip_published && isset($published[$key])) { $mark_skipped($key); continue; }
        $index[$key] = count($queue);
        $queue[] = $row;
    }

    $new_queue = $queue;
    if ($mode === 'replace' || $mode === 'mirror') {
        $new_queue = array();
        foreach ($order as $key) {
            if ($skip_published && isset($published[$key])) { $mark_skipped($key); continue; }
            $new_queue[] = $deduped[$key];
            if (isset($original_keys[$key])) $stats['updated']++;
            else $stats['added']++;
        }
    } elseif ($mode === 'append') {
        foreach ($order as $key) {
            if ($skip_published && isset($published[$key])) { $mark_skipped($key); continue; }
            if (isset($index[$key])) continue;
            $new_queue[] = $deduped[$key];
            $index[$key] = count($new_queue) - 1;
            $stats['added']++;
        }
    } else { // smart update/upsert: update existing rows, append new rows, do not remove missing rows
        foreach ($order as $key) {
            if ($skip_published && isset($published[$key])) { $mark_skipped($key); continue; }
            if (isset($index[$key])) {
                $new_queue[$index[$key]] = $deduped[$key];
                $stats['updated']++;
                continue;
            }
            $new_queue[] = $deduped[$key];
            $index[$key] = count($new_queue) - 1;
            $stats['added']++;
        }
    }

    $new_keys = array();
    foreach ($new_queue as $row) {
        $key = ppai_queue_row_key($row);
        if ($key !== '') $new_keys[$key] = true;
    }
    $stats['removed'] = count(array_diff_key($original_keys, $new_keys));
    $stats['accepted'] = $stats['added'] + $stats['updated'];
    $stats['queueCount'] = count($new_queue);
    if ($stats['queueCount'] > 5000) {
        return new WP_Error('ppai_queue_limit', 'Queue would exceed the 5000-row safety limit. Use Mirror or Replace mode, or reduce the CSV.', array('status'=>413));
    }
    update_option('ppai_csv_queue', array_values($new_queue), false);
    update_option('ppai_last_csv_sync', array_merge($stats, array('time' => current_time('mysql'), 'source' => 'wordpress-plugin-v5.6', 'queueHash' => md5(wp_json_encode($new_queue)))), false);
    return $stats;
    } finally {
        ppai_release_queue_lock($queue_lock);
    }
}

function ppai_run_auto_post() {
    $run_lock = ppai_acquire_run_lock(10 * MINUTE_IN_SECONDS);
    if ($run_lock === false) {
        return array('status'=>'skipped','message'=>'Another generation is already running.');
    }
    $post_id = 0;
    $attachment_id = 0;
    $published = false;

    try {
        // Take a short queue lock only while choosing and cleaning the next row.
        // This prevents a simultaneous CSV sync from being overwritten by the
        // stale queue snapshot used by the publisher.
        $initial_queue_lock = false;
        for ($lock_try = 0; $lock_try < 5 && $initial_queue_lock === false; $lock_try++) {
            $initial_queue_lock = ppai_acquire_queue_lock(60);
            if ($initial_queue_lock === false) usleep(200000);
        }
        if ($initial_queue_lock === false) {
            return array('status'=>'skipped','message'=>'Queue sync is running. Please retry in a moment.');
        }

        $queue = array();
        $row = array();
        $removed_invalid = 0;
        $removed_recent = 0;
        try {
            $queue = get_option('ppai_csv_queue', array());
            if (!is_array($queue)) $queue = array();

            // Recover safely after a server/process crash. A post can be published
            // just before PHP/Node stops, leaving its queue row behind. Remove only
            // very recent duplicates, so an intentional future re-run of the same
            // keyword is still possible.
            while (!empty($queue)) {
                $next = reset($queue);
                $candidate = ppai_normalize_queue_row($next);
                if (empty($candidate['keyword'])) {
                    array_shift($queue);
                    $removed_invalid++;
                    continue;
                }
                if (ppai_keyword_was_recently_published($candidate['keyword'], HOUR_IN_SECONDS)) {
                    array_shift($queue);
                    $removed_recent++;
                    continue;
                }
                $row = $candidate;
                break;
            }
            if ($removed_invalid > 0 || $removed_recent > 0) {
                update_option('ppai_csv_queue', array_values($queue), false);
            }
        } finally {
            ppai_release_queue_lock($initial_queue_lock);
        }

        if (empty($row['keyword'])) {
            $removed_total = $removed_invalid + $removed_recent;
            return array(
                'status'=>'skipped',
                'message'=>$removed_total > 0
                    ? sprintf('Removed %d invalid/recently-published queue row(s). Queue is now empty.', $removed_total)
                    : 'Queue is empty.',
                'queueRemaining'=>count($queue)
            );
        }

        $article = ppai_generate_article($row['topic'], $row['keyword'], $row['backlink'], $row['prompt']);
        if (is_wp_error($article)) throw new Exception($article->get_error_message());
        if (empty($article['title']) || empty($article['content'])) throw new Exception('Gemini returned empty article.');

        $content = wp_kses_post($article['content']);
        $plain_len = strlen(trim(wp_strip_all_tags($content)));
        if ($plain_len < 100) throw new Exception('Generated content too short; no post was published.');

        $cat_id = ppai_get_or_create_category_id($row['category']);
        if (is_wp_error($cat_id)) throw new Exception($cat_id->get_error_message());

        $author_id = ppai_default_author_id();
        $post_id = wp_insert_post(array(
            'post_title'    => sanitize_text_field($article['title']),
            'post_content'  => $content,
            'post_status'   => 'draft',
            'post_author'   => $author_id,
            'post_category' => array((int)$cat_id),
            'tags_input'    => $row['tags']
        ), true);
        if (is_wp_error($post_id)) throw new Exception($post_id->get_error_message());

        $image_warning = '';
        if (!empty($row['image'])) {
            $img = ppai_attach_featured_image($post_id, $row['image']);
            if (is_wp_error($img)) $image_warning = $img->get_error_message();
            else $attachment_id = (int) $img;
        }

        $meta = !empty($article['meta']) ? sanitize_text_field($article['meta']) : ppai_text_substr(wp_strip_all_tags($content), 0, 155);
        update_post_meta($post_id, 'rank_math_focus_keyword', sanitize_text_field($row['keyword']));
        update_post_meta($post_id, '_ppai_queue_keyword', sanitize_text_field($row['keyword']));
        update_post_meta($post_id, '_ppai_csv_row_source', 'sem-seo-bloger-' . PPAI_PLUGIN_VER);
        update_post_meta($post_id, 'rank_math_description', $meta);
        update_post_meta($post_id, '_aioseo_description', $meta);

        // Keep the image as the WordPress featured image only. Most themes
        // render it automatically; injecting it into post_content duplicated it.
        $updated = wp_update_post(array(
            'ID'          => $post_id,
            'post_status' => 'publish'
        ), true);
        if (is_wp_error($updated)) throw new Exception($updated->get_error_message());
        $published = true;

        // Reload the queue under a short lock so a simultaneous CSV sync cannot
        // overwrite this removal and re-introduce the just-published row.
        $queue_lock = false;
        for ($lock_try = 0; $lock_try < 5 && $queue_lock === false; $lock_try++) {
            $queue_lock = ppai_acquire_queue_lock(60);
            if ($queue_lock === false) usleep(200000);
        }
        $queue = get_option('ppai_csv_queue', array());
        if (!is_array($queue)) $queue = array();
        if ($queue_lock !== false) {
            try {
                $published_key = ppai_queue_key_from_keyword($row['keyword']);
                foreach ($queue as $queue_index => $queue_row) {
                    if (ppai_queue_row_key($queue_row) === $published_key) {
                        array_splice($queue, $queue_index, 1);
                        break;
                    }
                }
                update_option('ppai_csv_queue', array_values($queue), false);
            } finally {
                ppai_release_queue_lock($queue_lock);
            }
        } else {
            $image_warning = trim($image_warning . ' Queue was busy, so its published row will be cleaned on the next run.');
        }

        $entry = array(
            'post_id' => $post_id,
            'title' => sanitize_text_field($article['title']),
            'keyword' => sanitize_text_field($row['keyword']),
            'topic' => sanitize_text_field($row['topic']),
            'category' => sanitize_text_field($row['category']),
            'status' => 'Published',
            'post_status' => get_post_status($post_id),
            'post_url' => get_permalink($post_id),
            'edit_url' => get_edit_post_link($post_id, 'raw'),
            'warning' => $image_warning,
            'prompt_mode' => !empty($row['prompt']) ? 'per-post' : ((string)get_option('ppai_custom_prompt','') !== '' ? 'site-custom' : 'default'),
            'queue_remaining' => count($queue),
            'timestamp' => current_time('mysql')
        );
        ppai_history_add($entry);
        update_option('ppai_last_error', '', false);
        return array('status'=>'published','postId'=>$post_id,'title'=>$article['title'],'queueRemaining'=>count($queue),'warning'=>$image_warning);

    } catch (Throwable $e) {
        $safe_error = function_exists('ppai_redact_secret_text') ? ppai_redact_secret_text($e->getMessage()) : sanitize_text_field($e->getMessage());
        if ($attachment_id && !$published) {
            wp_delete_attachment($attachment_id, true);
        }
        if ($post_id && !$published) {
            wp_delete_post($post_id, true);
        }
        update_option('ppai_last_error', $safe_error, false);
        error_log('[PPAI] Error: ' . $safe_error);
        return new WP_Error('ppai_failed', $safe_error);
    } finally {
        ppai_release_run_lock($run_lock);
    }
}

<?php
if (!defined('ABSPATH')) exit;

add_action('admin_menu', function () {
    add_menu_page('Remote Controller Pro Writer', 'Gemini SEO', 'manage_options', 'gamini-seo', 'ppai_admin_panel', 'dashicons-edit-page', 81);
});

function ppai_notice($type, $message) {
    echo '<div class="notice notice-' . esc_attr($type) . ' is-dismissible"><p><strong>' . esc_html($message) . '</strong></p></div>';
}

function ppai_admin_handle_posts() {
    if (!current_user_can('manage_options')) return;

    if (isset($_POST['ppai_save_api'])) {
        check_admin_referer('ppai_save_api');
        update_option('ppai_gamini_api_key', sanitize_text_field($_POST['gamini_api_key'] ?? ''), false);
        update_option('ppai_gemini_model', sanitize_text_field($_POST['ppai_gemini_model'] ?? 'gemini-2.0-flash'), false);
        ppai_notice('success', 'API settings saved.');
    }

    if (isset($_POST['save_custom_prompt']) || isset($_POST['reset_custom_prompt'])) {
        check_admin_referer('ppai_save_prompt');
        if (isset($_POST['reset_custom_prompt'])) {
            update_option('ppai_custom_prompt', '', false);
            ppai_notice('success', 'Custom prompt reset to built-in default.');
        } else {
            $prompt = wp_kses_post($_POST['ppai_custom_prompt'] ?? '');
            if (strlen($prompt) > 20000) {
                ppai_notice('error', 'Prompt too long. Maximum 20000 characters.');
            } else {
                update_option('ppai_custom_prompt', $prompt, false);
                ppai_notice('success', 'Custom prompt saved. Remote Controller Prompt Studio can now use it.');
            }
        }
    }

    if (isset($_POST['ppai_enable_cron_submit'])) {
        check_admin_referer('ppai_save_cron');
        $val = !empty($_POST['ppai_enable_cron']);
        update_option('ppai_enable_cron', $val, false);
        ppai_schedule_cron_if_enabled();
        ppai_notice('success', $val ? 'WordPress cron enabled.' : 'WordPress cron disabled.');
    }

    if (isset($_POST['upload_csv']) && !empty($_FILES['csv_file']['tmp_name'])) {
        check_admin_referer('ppai_upload_csv');
        $csv = ppai_parse_csv($_FILES['csv_file']['tmp_name']);
        $mode = sanitize_key($_POST['ppai_csv_mode'] ?? 'smart');
        $skip_published = !empty($_POST['ppai_skip_published']); // v5 default is OFF so updated CSV rows are visible in Queue Preview
        if (empty($csv)) {
            ppai_notice('error', 'CSV has no valid rows. Make sure Keyword column exists.');
        } else {
            $sync = ppai_sync_csv_queue($csv, $mode, $skip_published);
            ppai_notice('success', sprintf(
                'CSV synced. Added: %d, Updated: %d, Removed: %d, Skipped published: %d, CSV duplicates fixed: %d, Queue now: %d rows.',
                $sync['added'], $sync['updated'], $sync['removed'], $sync['skippedPublished'], $sync['duplicatesInCsv'], $sync['queueCount']
            ));
        }
    }

    if (isset($_POST['run_generation_now'])) {
        check_admin_referer('ppai_run_now');
        $result = ppai_run_auto_post();
        if (is_wp_error($result)) ppai_notice('error', $result->get_error_message());
        else ppai_notice($result['status'] === 'published' ? 'success' : 'warning', $result['message'] ?? ('Status: ' . $result['status']));
    }

    if (isset($_POST['ppai_clear_queue'])) {
        check_admin_referer('ppai_clear_queue');
        update_option('ppai_csv_queue', array(), false);
        ppai_notice('success', 'Queue cleared.');
    }

    if (isset($_POST['ppai_clear_history'])) {
        check_admin_referer('ppai_clear_history');
        update_option('ppai_post_history', array(), false);
        update_option('ppai_last_error', '', false);
        ppai_notice('success', 'History and last error cleared.');
    }
}

function ppai_admin_panel() {
    if (!current_user_can('manage_options')) { return; }
    ppai_admin_handle_posts();

    $error = get_option('ppai_last_error', '');
    $queue = get_option('ppai_csv_queue', array());
    if (!is_array($queue)) $queue = array();
    $history = get_option('ppai_post_history', array());
    if (!is_array($history)) $history = array();
    $cron_enabled = (bool) get_option('ppai_enable_cron', false);
    $next_cron = wp_next_scheduled('ppai_auto_post_event');
    $last_csv_sync = get_option('ppai_last_csv_sync', array());
    if (!is_array($last_csv_sync)) $last_csv_sync = array();
    $ajax_nonce = wp_create_nonce('ppai_manual_run');
    ?>
    <style>
      .ppai-wrap{max-width:1360px}.ppai-hero{position:relative;overflow:hidden;background:radial-gradient(800px 260px at 15% 0%,rgba(0,229,255,.22),transparent 60%),linear-gradient(135deg,#08111f,#172554 58%,#0f766e);color:#fff;border-radius:24px;padding:28px;margin:18px 0;box-shadow:0 24px 70px rgba(0,0,0,.22)}.ppai-hero:after{content:"";position:absolute;right:-60px;top:-80px;width:240px;height:240px;border-radius:999px;background:rgba(255,255,255,.08)}.ppai-hero h1{color:#fff;margin:0 0 8px;font-size:34px;letter-spacing:-.03em}.ppai-hero p{font-size:15px;margin:0;opacity:.92}.ppai-grid{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:18px}.ppai-card{background:#fff;border:1px solid #dbe6f3;border-radius:20px;padding:20px;box-shadow:0 16px 45px rgba(15,23,42,.08)}.ppai-card h2{margin-top:0;color:#0f172a}.ppai-kpis{display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:12px;margin:16px 0}.ppai-kpi{background:linear-gradient(180deg,#fff,#f8fbff);border:1px solid #dbe6f3;border-radius:18px;padding:16px;box-shadow:0 10px 26px rgba(15,23,42,.05)}.ppai-kpi strong{display:block;font-size:28px;color:#0f172a}.ppai-muted{color:#64748b}.ppai-actions{display:flex;gap:10px;flex-wrap:wrap;align-items:center}.ppai-table-wrap{max-height:460px;overflow:auto;border:1px solid #dbe6f3;border-radius:14px}.ppai-table-wrap table{border:none!important}.ppai-danger{color:#b91c1c}.ppai-field{width:100%;max-width:640px}.ppai-card textarea{width:100%;min-height:220px}.ppai-sync-mode{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:10px;margin:12px 0}.ppai-radio{border:1px solid #dbe6f3;border-radius:16px;padding:14px;background:#f8fafc;transition:.18s}.ppai-radio:hover{border-color:#22d3ee;box-shadow:0 0 0 4px rgba(34,211,238,.12)}.ppai-radio strong{display:block;color:#0f172a}.ppai-radio small{display:block;color:#64748b;margin-top:3px}.ppai-sync-status{margin-top:12px;padding:14px;border-radius:16px;background:linear-gradient(135deg,#ecfeff,#f0fdf4);border:1px solid #a7f3d0}.ppai-preview-head{display:flex;justify-content:space-between;align-items:center;gap:10px;flex-wrap:wrap}.button-primary{background:#0f766e!important;border-color:#0f766e!important}.button-secondary{border-color:#22d3ee!important;color:#155e75!important}@media(max-width:900px){.ppai-grid,.ppai-kpis,.ppai-sync-mode{grid-template-columns:1fr}}
    
.ppai-wrap{font-family:Inter,system-ui,-apple-system,BlinkMacSystemFont,"Segoe UI",sans-serif}.ppai-hero{background:radial-gradient(700px 240px at 12% 0%,rgba(0,229,255,.26),transparent 60%),radial-gradient(700px 240px at 95% 0%,rgba(124,58,237,.28),transparent 62%),linear-gradient(135deg,#030712,#081A32 58%,#0F766E)!important;border:1px solid rgba(0,229,255,.28);box-shadow:0 30px 100px rgba(0,0,0,.2),0 0 60px rgba(0,229,255,.1)!important}.ppai-hero h1{font-size:38px!important;letter-spacing:-.05em}.ppai-card,.ppai-kpi{border-radius:24px!important;border:1px solid #d8e7fb!important;box-shadow:0 18px 48px rgba(15,23,42,.08)!important}.ppai-card h2{font-size:23px;letter-spacing:-.03em}.ppai-radio{border-radius:18px!important}.ppai-radio:hover{transform:translateY(-1px)}.button-primary{background:linear-gradient(135deg,#00A9C8,#0F766E)!important;border:none!important;border-radius:10px!important;font-weight:700}.button-secondary{border-radius:10px!important}.ppai-sync-status{border-radius:18px!important;background:linear-gradient(135deg,#ecfeff,#f0fdf4)!important}.ppai-table-wrap{border-radius:18px!important}.ppai-kpi strong{background:linear-gradient(90deg,#0f172a,#0e7490);-webkit-background-clip:text;background-clip:text;color:transparent}
</style>
    <div class="wrap ppai-wrap">
      <div class="ppai-hero">
        <h1>Remote Controller Pro Writer</h1>
        <p>World-class CSV queue → Gemini article → WordPress publishing. Updated CSV rows are visible immediately in the queue preview and Remote Controller dashboard.</p>
      </div>

      <?php if (!empty($error)): ?>
        <div class="notice notice-error"><p><strong>Last Error:</strong> <?php echo esc_html($error); ?></p></div>
      <?php endif; ?>

      <div class="ppai-kpis">
        <div class="ppai-kpi"><span class="ppai-muted">Queue</span><strong><?php echo esc_html(count($queue)); ?></strong></div>
        <div class="ppai-kpi"><span class="ppai-muted">History</span><strong><?php echo esc_html(count($history)); ?></strong></div>
        <div class="ppai-kpi"><span class="ppai-muted">WP Cron</span><strong><?php echo $cron_enabled ? 'On' : 'Off'; ?></strong></div>
        <div class="ppai-kpi"><span class="ppai-muted">Next Cron</span><strong style="font-size:14px"><?php echo $next_cron ? esc_html(date_i18n('Y-m-d H:i', $next_cron)) : '-'; ?></strong></div>
      </div>

      <div class="ppai-grid">
        <div class="ppai-card">
          <h2>API Settings</h2>
          <form method="post">
            <?php wp_nonce_field('ppai_save_api'); ?>
            <p><label>Gemini API Key<br><input name="gamini_api_key" type="password" value="<?php echo esc_attr(get_option('ppai_gamini_api_key', '')); ?>" class="regular-text ppai-field" autocomplete="off" /></label></p>
            <p><label>Gemini Model<br><input name="ppai_gemini_model" type="text" value="<?php echo esc_attr(get_option('ppai_gemini_model', 'gemini-2.0-flash')); ?>" class="regular-text ppai-field" /></label></p>
            <input type="submit" name="ppai_save_api" class="button button-primary" value="Save API Settings">
          </form>
        </div>

        <div class="ppai-card">
          <h2>Run Controls</h2>
          <div class="ppai-actions">
            <form method="post"><?php wp_nonce_field('ppai_run_now'); ?><input type="submit" name="run_generation_now" class="button button-primary" value="▶ Generate One Now"></form>
            <button id="ppai_start_auto" class="button button-secondary">Start Browser Auto</button>
            <button id="ppai_stop_auto" class="button" style="display:none;">Stop</button>
            <label>Every <input type="number" id="auto_interval" min="10" value="60" style="width:80px;" /> seconds</label>
          </div>
          <div id="ppai_auto_status" style="margin-top:12px;font-weight:700;"></div>
          <hr>
          <form method="post" class="ppai-actions">
            <?php wp_nonce_field('ppai_save_cron'); ?>
            <label><input type="checkbox" name="ppai_enable_cron" value="1" <?php checked($cron_enabled); ?>> Enable WordPress cron every 4 minutes</label>
            <input type="submit" name="ppai_enable_cron_submit" class="button" value="Save Cron">
          </form>
        </div>

        <div class="ppai-card">
          <h2>CSV Auto Update / Queue Sync v8</h2>
          <p class="ppai-muted">Required: <code>Keyword</code>. Optional: <code>Topic</code>, <code>Category</code>, <code>Tags</code>, <code>image</code>, <code>Backlink</code>. Works with comma, semicolon, tab CSV, Google Sheet exports, and even CSV without a header row.</p>
          <form method="post" enctype="multipart/form-data">
            <?php wp_nonce_field('ppai_upload_csv'); ?>
            <p><input type="file" name="csv_file" accept=".csv,text/csv" required></p>
            <div class="ppai-sync-mode">
              <label class="ppai-radio"><input type="radio" name="ppai_csv_mode" value="smart" checked> <strong>Smart Update</strong><small>Update existing keywords, append new keywords, keep old queue rows.</small></label>
              <label class="ppai-radio"><input type="radio" name="ppai_csv_mode" value="append"> <strong>Append New Only</strong><small>Add only keywords not already in the queue.</small></label>
              <label class="ppai-radio"><input type="radio" name="ppai_csv_mode" value="mirror"> <strong>Mirror CSV</strong><small>Queue becomes exactly this CSV after duplicate cleanup.</small></label>
              <label class="ppai-radio"><input type="radio" name="ppai_csv_mode" value="replace"> <strong>Replace Queue</strong><small>Clear current queue and load this CSV.</small></label>
            </div>
            <p><label><input type="checkbox" name="ppai_skip_published" value="1"> Skip already published keywords <span class="ppai-muted">(leave OFF when you want the updated CSV sheet to appear in Queue Preview)</span></label></p>
            <input type="submit" name="upload_csv" class="button button-primary" value="Sync CSV / Auto Update Queue">
          </form>
          <?php if (!empty($last_csv_sync)): ?>
            <div class="ppai-sync-status">
              <strong>Last CSV Sync:</strong>
              <?php echo esc_html($last_csv_sync['time'] ?? ''); ?> —
              Added <?php echo esc_html($last_csv_sync['added'] ?? 0); ?>,
              Updated <?php echo esc_html($last_csv_sync['updated'] ?? 0); ?>,
              Removed <?php echo esc_html($last_csv_sync['removed'] ?? 0); ?>,
              Skipped Published <?php echo esc_html($last_csv_sync['skippedPublished'] ?? 0); ?>,
              Queue <?php echo esc_html($last_csv_sync['queueCount'] ?? count($queue)); ?>.
            </div>
          <?php endif; ?>
          <form method="post" style="margin-top:12px;" onsubmit="return confirm('Clear all queue rows?')">
            <?php wp_nonce_field('ppai_clear_queue'); ?>
            <input type="submit" name="ppai_clear_queue" class="button" value="Clear Queue">
          </form>
        </div>

        <div class="ppai-card">
          <h2>Prompt Studio</h2>
          <form method="post">
            <?php wp_nonce_field('ppai_save_prompt'); ?>
            <textarea name="ppai_custom_prompt" placeholder="Use $topic and $keyword. Optional: $backlink"><?php echo esc_textarea(get_option('ppai_custom_prompt', '')); ?></textarea>
            <p class="ppai-muted">Variables supported: <code>$topic</code>, <code>$keyword</code>, <code>$backlink</code>, <code>{{topic}}</code>, <code>{{keyword}}</code>, <code>{{backlink}}</code>. Leave blank to use the built-in Indian financial SEO prompt.</p>
            <div class="ppai-actions">
              <input type="submit" name="save_custom_prompt" class="button button-secondary" value="Save Prompt">
              <input type="submit" name="reset_custom_prompt" class="button" value="Reset to Default" onclick="return confirm('Reset custom prompt to default?')">
            </div>
          </form>
        </div>
      </div>

      <div class="ppai-card" style="margin-top:18px;">
        <div class="ppai-preview-head"><h2>Queue Preview</h2><span class="ppai-muted">Smart-sync duplicates are automatically cleaned by Keyword.</span></div>
        <div class="ppai-table-wrap">
          <table class="widefat striped">
            <thead><tr><th>#</th><th>Keyword</th><th>Topic</th><th>Category</th><th>Tags</th><th>Backlink</th></tr></thead>
            <tbody>
              <?php if (empty($queue)): ?>
                <tr><td colspan="6">No queue rows.</td></tr>
              <?php else: $i=1; foreach (array_slice($queue, 0, 200) as $r): ?>
                <tr><td><?php echo esc_html($i++); ?></td><td><?php echo esc_html($r['Keyword'] ?? ''); ?></td><td><?php echo esc_html($r['Topic'] ?? ''); ?></td><td><?php echo esc_html($r['Category'] ?? ''); ?></td><td><?php echo esc_html($r['Tags'] ?? ''); ?></td><td><?php echo esc_html($r['Backlink'] ?? ($r['BacklinkURL'] ?? '')); ?></td></tr>
              <?php endforeach; endif; ?>
            </tbody>
          </table>
        </div>
      </div>

      <div class="ppai-card" style="margin-top:18px;">
        <h2>History</h2>
        <form method="post" onsubmit="return confirm('Clear history and last error?')" style="margin-bottom:12px;">
          <?php wp_nonce_field('ppai_clear_history'); ?>
          <input type="submit" name="ppai_clear_history" class="button" value="Clear History">
        </form>
        <div class="ppai-table-wrap">
          <table class="widefat striped">
            <thead><tr><th>Time</th><th>Post ID</th><th>Title</th><th>Keyword</th><th>Status</th><th>Warning</th></tr></thead>
            <tbody>
              <?php if (empty($history)): ?>
                <tr><td colspan="6">No history yet.</td></tr>
              <?php else: foreach (array_reverse(array_slice($history, -200)) as $h): ?>
                <tr><td><?php echo esc_html($h['timestamp'] ?? ''); ?></td><td><?php echo esc_html($h['post_id'] ?? ''); ?></td><td><?php echo esc_html($h['title'] ?? ''); ?></td><td><?php echo esc_html($h['keyword'] ?? ''); ?></td><td><?php echo esc_html($h['status'] ?? ''); ?></td><td><?php echo esc_html($h['warning'] ?? ''); ?></td></tr>
              <?php endforeach; endif; ?>
            </tbody>
          </table>
        </div>
      </div>
    </div>

    <script>
    document.addEventListener('DOMContentLoaded', function () {
      let intervalId = null;
      const startBtn = document.getElementById('ppai_start_auto');
      const stopBtn = document.getElementById('ppai_stop_auto');
      const intervalInput = document.getElementById('auto_interval');
      const statusBox = document.getElementById('ppai_auto_status');
      const nonce = <?php echo wp_json_encode($ajax_nonce); ?>;
      function triggerAutoPost() {
        statusBox.innerText = 'Running...';
        fetch(ajaxurl, {
          method: 'POST',
          headers: {'Content-Type': 'application/x-www-form-urlencoded'},
          body: new URLSearchParams({ action: 'ppai_run_manual_post', nonce })
        })
        .then(res => res.json())
        .then(data => {
          if (!data.success) throw new Error(data.data && data.data.message ? data.data.message : 'Generation failed');
          statusBox.innerText = '✔ ' + (data.data.title || data.data.message || data.data.status) + ' at ' + new Date().toLocaleTimeString();
        })
        .catch(err => { statusBox.innerText = '❌ ' + err.message; });
      }
      startBtn.addEventListener('click', () => {
        const seconds = Math.max(10, parseInt(intervalInput.value || '60', 10));
        triggerAutoPost();
        intervalId = setInterval(triggerAutoPost, seconds * 1000);
        startBtn.style.display = 'none'; stopBtn.style.display = 'inline-block';
      });
      stopBtn.addEventListener('click', () => {
        clearInterval(intervalId);
        startBtn.style.display = 'inline-block'; stopBtn.style.display = 'none';
        statusBox.innerText = 'Stopped.';
      });
    });
    </script>
    <?php
}

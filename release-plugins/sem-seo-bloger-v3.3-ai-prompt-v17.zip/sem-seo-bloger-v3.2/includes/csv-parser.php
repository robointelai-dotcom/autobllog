<?php
if (!defined('ABSPATH')) exit;

function ppai_clean_csv_value($value) {
    $value = is_string($value) ? $value : '';
    $value = preg_replace('/^\xEF\xBB\xBF/', '', $value);
    $value = str_replace(array("\xC2\xA0", '“', '”', '‘', '’'), array(' ', '"', '"', "'", "'"), $value);
    $value = preg_replace('/[\x00-\x08\x0B\x0C\x0E-\x1F]/', '', $value);
    return trim($value);
}

function ppai_header_alias($header) {
    $key = strtolower(preg_replace('/[\s_\-]+/', '', ppai_clean_csv_value($header)));
    $aliases = array(
        'keyword' => 'Keyword', 'keywords' => 'Keyword', 'title' => 'Keyword', 'posttitle' => 'Keyword',
        'topic' => 'Topic', 'subject' => 'Topic', 'blogtopic' => 'Topic',
        'category' => 'Category', 'categories' => 'Category',
        'tags' => 'Tags', 'tag' => 'Tags',
        'image' => 'image', 'imageurl' => 'image', 'imageurls' => 'image', 'featuredimage' => 'image', 'image_url' => 'image', 'images' => 'image',
        'backlink' => 'Backlink', 'backlinkurl' => 'Backlink', 'backlinkurls' => 'Backlink', 'backlink_url' => 'Backlink', 'url' => 'Backlink', 'link' => 'Backlink',
        'prompt' => 'Prompt', 'customprompt' => 'Prompt', 'custom_prompt' => 'Prompt', 'postprompt' => 'Prompt', 'aiprompt' => 'Prompt'
    );
    return isset($aliases[$key]) ? $aliases[$key] : ppai_clean_csv_value($header);
}

function ppai_csv_detect_delimiter($content) {
    $lines = preg_split('/\r\n|\n|\r/', (string) $content);
    $sample = '';
    foreach ($lines as $line) {
        if (trim($line) !== '') { $sample = $line; break; }
    }
    if ($sample === '') return ',';
    $best = ','; $best_count = 0;
    foreach (array(',', ';', "\t", '|') as $delim) {
        $cols = str_getcsv($sample, $delim);
        $count = is_array($cols) ? count($cols) : 0;
        if ($count > $best_count) { $best_count = $count; $best = $delim; }
    }
    return $best;
}

function ppai_csv_has_header($row) {
    if (!is_array($row)) return false;
    foreach ($row as $cell) {
        if (ppai_header_alias($cell) === 'Keyword') return true;
    }
    return false;
}

function ppai_parse_csv($file) {
    $content = @file_get_contents($file);
    if ($content === false || trim($content) === '') return array();
    $content = preg_replace('/^\xEF\xBB\xBF/', '', $content);
    $content = str_replace(array("\r\n", "\r"), "\n", $content);
    $delimiter = ppai_csv_detect_delimiter($content);

    $handle = fopen('php://temp', 'r+');
    fwrite($handle, $content);
    rewind($handle);

    $rows = array();
    while (($row = fgetcsv($handle, 0, $delimiter)) !== false) {
        if (!is_array($row)) continue;
        $row = array_map('ppai_clean_csv_value', $row);
        if (!array_filter($row, function($v){ return trim((string)$v) !== ''; })) continue;
        $rows[] = $row;
    }
    fclose($handle);
    if (empty($rows)) return array();

    $first = $rows[0];
    $has_header = ppai_csv_has_header($first);
    $header = $has_header ? array_map('ppai_header_alias', $first) : array('Keyword', 'Topic', 'Category', 'Tags', 'image', 'Backlink', 'Prompt');
    $data_rows = $has_header ? array_slice($rows, 1) : $rows;

    $data = array();
    foreach ($data_rows as $row) {
        $assoc = array();
        foreach ($header as $i => $name) {
            $assoc[$name] = isset($row[$i]) ? ppai_clean_csv_value($row[$i]) : '';
        }
        if (empty($assoc['Keyword'])) continue;
        $data[] = array(
            'Keyword' => sanitize_text_field($assoc['Keyword']),
            'Topic' => isset($assoc['Topic']) && $assoc['Topic'] !== '' ? sanitize_text_field($assoc['Topic']) : sanitize_text_field($assoc['Keyword']),
            'Category' => isset($assoc['Category']) && $assoc['Category'] !== '' ? sanitize_text_field($assoc['Category']) : 'Uncategorized',
            'Tags' => isset($assoc['Tags']) ? sanitize_text_field($assoc['Tags']) : '',
            'image' => isset($assoc['image']) ? esc_url_raw($assoc['image']) : '',
            'Backlink' => isset($assoc['Backlink']) ? esc_url_raw($assoc['Backlink']) : '',
            'Prompt' => isset($assoc['Prompt']) ? wp_kses_post($assoc['Prompt']) : '',
        );
        if (count($data) >= 5000) break;
    }
    return $data;
}

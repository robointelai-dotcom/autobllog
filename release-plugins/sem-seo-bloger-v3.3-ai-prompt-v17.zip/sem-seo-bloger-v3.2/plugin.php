<?php
/*
Plugin Name: SEM SEO BLOGER
Description: Gemini-powered SEO blog generator with CSV queue, safe manual generation, and remote bridge support.
Version: 5.4.0
Author: seo seo manager
*/
if (!defined('ABSPATH')) exit;

define('PPAI_PLUGIN_PATH', plugin_dir_path(__FILE__));
define('PPAI_PLUGIN_VER', '5.4.0');

require_once ABSPATH . 'wp-admin/includes/media.php';
require_once ABSPATH . 'wp-admin/includes/file.php';
require_once ABSPATH . 'wp-admin/includes/image.php';

include_once PPAI_PLUGIN_PATH . 'includes/csv-parser.php';
include_once PPAI_PLUGIN_PATH . 'includes/gamini-api.php';
include_once PPAI_PLUGIN_PATH . 'includes/admin-ui.php';

add_action('wp_head', function() {
    if (is_single()) {
        echo '<style>.post-thumb-img-content.post-thumb{display:none!important}</style>';
    }
});

function ppai_custom_cron_interval($schedules) {
    $schedules['every_4_minutes'] = array(
        'interval' => 240,
        'display' => __('Every 4 Minutes', 'ppai')
    );
    return $schedules;
}
add_filter('cron_schedules', 'ppai_custom_cron_interval');

function ppai_schedule_cron_if_enabled() {
    if (get_option('ppai_enable_cron', false)) {
        if (!wp_next_scheduled('ppai_auto_post_event')) {
            wp_schedule_event(time() + 60, 'every_4_minutes', 'ppai_auto_post_event');
        }
    } else {
        wp_clear_scheduled_hook('ppai_auto_post_event');
    }
}

register_activation_hook(__FILE__, 'ppai_schedule_cron_if_enabled');
register_deactivation_hook(__FILE__, function(){ wp_clear_scheduled_hook('ppai_auto_post_event'); delete_transient('ppai_run_lock'); });
add_action('ppai_auto_post_event', 'ppai_run_auto_post');
add_action('init', 'ppai_schedule_cron_if_enabled');

add_action('admin_init', function() {
    register_setting('ppai-settings-group', 'ppai_gamini_api_key', array('sanitize_callback'=>'sanitize_text_field'));
    register_setting('ppai-settings-group', 'ppai_custom_prompt', array('sanitize_callback'=>'wp_kses_post'));
    register_setting('ppai-settings-group', 'ppai_gemini_model', array('sanitize_callback'=>'sanitize_text_field'));
});

add_action('wp_ajax_ppai_run_manual_post', function(){
    if (!current_user_can('manage_options')) {
        wp_send_json_error(array('message'=>'Permission denied'), 403);
    }
    check_ajax_referer('ppai_manual_run', 'nonce');
    $result = ppai_run_auto_post();
    if (is_wp_error($result)) {
        wp_send_json_error(array('message'=>$result->get_error_message()), 500);
    }
    wp_send_json_success($result);
});

function ppai_normalize_queue_row($row) {
    $row = is_array($row) ? $row : array();
    $keyword = isset($row['Keyword']) ? sanitize_text_field($row['Keyword']) : '';
    $topic = isset($row['Topic']) && $row['Topic'] !== '' ? sanitize_text_field($row['Topic']) : $keyword;
    $category = isset($row['Category']) && $row['Category'] !== '' ? sanitize_text_field($row['Category']) : 'Uncategorized';
    $tags_raw = isset($row['Tags']) ? sanitize_text_field($row['Tags']) : '';
    $image = '';
    if (!empty($row['image'])) $image = esc_url_raw($row['image']);
    elseif (!empty($row['Image'])) $image = esc_url_raw($row['Image']);
    elseif (!empty($row['image_url'])) $image = esc_url_raw($row['image_url']);
    $backlink = '';
    if (!empty($row['Backlink'])) $backlink = esc_url_raw($row['Backlink']);
    elseif (!empty($row['BacklinkURL'])) $backlink = esc_url_raw($row['BacklinkURL']);
    elseif (!empty($row['backlink_url'])) $backlink = esc_url_raw($row['backlink_url']);
    $prompt = '';
    if (!empty($row['Prompt'])) $prompt = wp_kses_post((string) $row['Prompt']);
    elseif (!empty($row['CustomPrompt'])) $prompt = wp_kses_post((string) $row['CustomPrompt']);
    elseif (!empty($row['custom_prompt'])) $prompt = wp_kses_post((string) $row['custom_prompt']);
    elseif (!empty($row['PostPrompt'])) $prompt = wp_kses_post((string) $row['PostPrompt']);
    if (strlen($prompt) > 20000) $prompt = substr($prompt, 0, 20000);

    $tags = array_filter(array_map('trim', explode(',', $tags_raw)));
    return compact('keyword','topic','category','tags','image','backlink','prompt');
}

function ppai_get_or_create_category_id($category_name) {
    $category_name = $category_name ? $category_name : 'Uncategorized';
    $cat_id = (int) get_cat_ID($category_name);
    if ($cat_id > 0) return $cat_id;
    $created = wp_create_category($category_name);
    if (is_wp_error($created)) return $created;
    return (int) $created;
}

function ppai_attach_featured_image($post_id, $image_url) {
    if (empty($image_url)) return 0;
    $tmp = download_url($image_url, 30);
    if (is_wp_error($tmp)) return $tmp;

    $path = parse_url($image_url, PHP_URL_PATH);
    $name = $path ? basename($path) : ('featured-' . time() . '.jpg');
    if (!$name || $name === '/') $name = 'featured-' . time() . '.jpg';

    $file_array = array('name' => sanitize_file_name($name), 'tmp_name' => $tmp);
    $file = wp_handle_sideload($file_array, array('test_form' => false));
    if (isset($file['error'])) {
        @unlink($tmp);
        return new WP_Error('ppai_image_error', $file['error']);
    }

    $attachment = array(
        'post_mime_type' => $file['type'],
        'post_title'     => sanitize_file_name(pathinfo($file['file'], PATHINFO_FILENAME)),
        'post_content'   => '',
        'post_status'    => 'inherit'
    );
    $attach_id = wp_insert_attachment($attachment, $file['file'], $post_id);
    if (is_wp_error($attach_id)) return $attach_id;

    $attach_data = wp_generate_attachment_metadata($attach_id, $file['file']);
    wp_update_attachment_metadata($attach_id, $attach_data);
    set_post_thumbnail($post_id, $attach_id);
    return $attach_id;
}

function ppai_history_add($entry) {
    $history = get_option('ppai_post_history', array());
    if (!is_array($history)) $history = array();
    $history[] = $entry;
    if (count($history) > 500) $history = array_slice($history, -500);
    update_option('ppai_post_history', $history, false);
}


function ppai_queue_key_from_keyword($keyword) {
    $keyword = is_string($keyword) ? $keyword : '';
    $keyword = wp_strip_all_tags($keyword);
    $keyword = preg_replace('/\s+/u', ' ', trim($keyword));
    if (function_exists('mb_strtolower')) return mb_strtolower($keyword, 'UTF-8');
    return strtolower($keyword);
}

function ppai_queue_row_key($row) {
    $row = ppai_normalize_queue_row(is_array($row) ? $row : array());
    return ppai_queue_key_from_keyword($row['keyword']);
}

function ppai_queue_canonical_row($row) {
    $row = ppai_normalize_queue_row(is_array($row) ? $row : array());
    $tags = is_array($row['tags']) ? implode(', ', array_map('sanitize_text_field', $row['tags'])) : sanitize_text_field((string) $row['tags']);
    return array(
        'Keyword'  => sanitize_text_field($row['keyword']),
        'Topic'    => sanitize_text_field($row['topic']),
        'Category' => sanitize_text_field($row['category']),
        'Tags'     => $tags,
        'image'    => esc_url_raw($row['image']),
        'Backlink' => esc_url_raw($row['backlink']),
        'Prompt'   => wp_kses_post($row['prompt']),
    );
}

function ppai_get_published_queue_keys() {
    $keys = array();
    $history = get_option('ppai_post_history', array());
    if (is_array($history)) {
        foreach ($history as $entry) {
            if (!empty($entry['keyword'])) {
                $k = ppai_queue_key_from_keyword($entry['keyword']);
                if ($k !== '') $keys[$k] = true;
            }
        }
    }

    $posts = get_posts(array(
        'post_type'      => 'post',
        'post_status'    => array('publish', 'draft', 'pending', 'future'),
        'posts_per_page' => 1000,
        'fields'         => 'ids',
        'meta_query'     => array(
            'relation' => 'OR',
            array('key' => 'rank_math_focus_keyword', 'compare' => 'EXISTS'),
            array('key' => '_ppai_queue_keyword', 'compare' => 'EXISTS')
        ),
        'no_found_rows'  => true,
    ));
    foreach ($posts as $post_id) {
        $kw = get_post_meta($post_id, 'rank_math_focus_keyword', true);
        if ($kw === '') $kw = get_post_meta($post_id, '_ppai_queue_keyword', true);
        $k = ppai_queue_key_from_keyword($kw);
        if ($k !== '') $keys[$k] = true;
    }
    return $keys;
}

function ppai_sync_csv_queue($incoming_rows, $mode = 'smart', $skip_published = false) {
    $allowed = array('smart', 'append', 'replace', 'mirror');
    $mode = in_array($mode, $allowed, true) ? $mode : 'smart';
    $incoming_rows = is_array($incoming_rows) ? $incoming_rows : array();
    $skip_published = (bool) $skip_published;

    $stats = array(
        'mode' => $mode,
        'received' => count($incoming_rows),
        'accepted' => 0,
        'added' => 0,
        'updated' => 0,
        'removed' => 0,
        'invalid' => 0,
        'duplicatesInCsv' => 0,
        'duplicatesInQueue' => 0,
        'skippedPublished' => 0,
        'queueCount' => 0,
    );

    $deduped = array();
    $order = array();
    foreach ($incoming_rows as $row) {
        $row = ppai_queue_canonical_row($row);
        $key = ppai_queue_row_key($row);
        if ($key === '') { $stats['invalid']++; continue; }
        if (isset($deduped[$key])) { $stats['duplicatesInCsv']++; }
        else { $order[] = $key; }
        $deduped[$key] = $row; // latest CSV value wins for the same keyword
    }

    $current = get_option('ppai_csv_queue', array());
    if (!is_array($current)) $current = array();
    $queue = array();
    $index = array();
    foreach ($current as $row) {
        $row = ppai_queue_canonical_row($row);
        $key = ppai_queue_row_key($row);
        if ($key === '') { continue; }
        if (isset($index[$key])) { $stats['duplicatesInQueue']++; continue; }
        $index[$key] = count($queue);
        $queue[] = $row;
    }

    $published = $skip_published ? ppai_get_published_queue_keys() : array();
    $new_queue = $queue;

    if ($mode === 'replace' || $mode === 'mirror') {
        $new_queue = array();
        foreach ($order as $key) {
            if ($skip_published && isset($published[$key])) { $stats['skippedPublished']++; continue; }
            $new_queue[] = $deduped[$key];
            $stats['added']++;
        }
        $stats['removed'] = max(0, count($queue) - count($new_queue));
    } elseif ($mode === 'append') {
        foreach ($order as $key) {
            if (isset($index[$key])) { continue; }
            if ($skip_published && isset($published[$key])) { $stats['skippedPublished']++; continue; }
            $new_queue[] = $deduped[$key];
            $index[$key] = count($new_queue) - 1;
            $stats['added']++;
        }
    } else { // smart update/upsert: update existing rows, append new rows, do not remove missing rows
        foreach ($order as $key) {
            if (isset($index[$key])) {
                $new_queue[$index[$key]] = $deduped[$key];
                $stats['updated']++;
                continue;
            }
            if ($skip_published && isset($published[$key])) { $stats['skippedPublished']++; continue; }
            $new_queue[] = $deduped[$key];
            $index[$key] = count($new_queue) - 1;
            $stats['added']++;
        }
    }

    $stats['accepted'] = $stats['added'] + $stats['updated'];
    $stats['queueCount'] = count($new_queue);
    update_option('ppai_csv_queue', array_values($new_queue), false);
    update_option('ppai_last_csv_sync', array_merge($stats, array('time' => current_time('mysql'), 'source' => 'wordpress-plugin-v5', 'queueHash' => md5(wp_json_encode($new_queue)))), false);
    return $stats;
}

function ppai_run_auto_post() {
    if (get_transient('ppai_run_lock')) {
        return array('status'=>'skipped','message'=>'Another generation is already running.');
    }
    set_transient('ppai_run_lock', 1, 10 * MINUTE_IN_SECONDS);

    try {
        $queue = get_option('ppai_csv_queue', array());
        if (!is_array($queue)) $queue = array();
        if (empty($queue)) {
            return array('status'=>'skipped','message'=>'Queue is empty.');
        }

        $next = reset($queue);
        $row = ppai_normalize_queue_row($next);
        if (empty($row['keyword'])) {
            array_shift($queue);
            update_option('ppai_csv_queue', array_values($queue), false);
            throw new Exception('Keyword is missing in first queue row. Removed invalid row.');
        }

        $article = ppai_generate_article($row['topic'], $row['keyword'], $row['backlink'], $row['prompt']);
        if (is_wp_error($article)) throw new Exception($article->get_error_message());
        if (empty($article['title']) || empty($article['content'])) throw new Exception('Gemini returned empty article.');

        $cat_id = ppai_get_or_create_category_id($row['category']);
        if (is_wp_error($cat_id)) throw new Exception($cat_id->get_error_message());

        $author_id = get_current_user_id() ? get_current_user_id() : 1;
        $post_id = wp_insert_post(array(
            'post_title'    => sanitize_text_field($article['title']),
            'post_content'  => '',
            'post_status'   => 'draft',
            'post_author'   => $author_id,
            'post_category' => array((int)$cat_id),
            'tags_input'    => $row['tags']
        ), true);
        if (is_wp_error($post_id)) throw new Exception($post_id->get_error_message());

        $image_warning = '';
        if (!empty($row['image'])) {
            $img = ppai_attach_featured_image($post_id, $row['image']);
            if (is_wp_error($img)) $image_warning = $img->get_error_message();
        }

        $content = wp_kses_post($article['content']);
        $featured_img_html = get_the_post_thumbnail($post_id, 'large', array('style'=>'max-width:100%;height:auto;margin-bottom:20px;'));
        if ($featured_img_html) $content = $featured_img_html . "\n\n" . $content;

        $plain_len = strlen(trim(wp_strip_all_tags($content)));
        if ($plain_len < 100) throw new Exception('Generated content too short; post left as draft.');

        $updated = wp_update_post(array(
            'ID'           => $post_id,
            'post_content' => $content,
            'post_status'  => 'publish'
        ), true);
        if (is_wp_error($updated)) throw new Exception($updated->get_error_message());

        $meta = !empty($article['meta']) ? sanitize_text_field($article['meta']) : substr(wp_strip_all_tags($content), 0, 155);
        update_post_meta($post_id, 'rank_math_focus_keyword', sanitize_text_field($row['keyword']));
        update_post_meta($post_id, '_ppai_queue_keyword', sanitize_text_field($row['keyword']));
        update_post_meta($post_id, '_ppai_csv_row_source', 'sem-seo-bloger-v8');
        update_post_meta($post_id, 'rank_math_description', $meta);
        update_post_meta($post_id, '_aioseo_description', $meta);

        array_shift($queue);
        update_option('ppai_csv_queue', array_values($queue), false);

        $entry = array(
            'post_id' => $post_id,
            'title' => sanitize_text_field($article['title']),
            'keyword' => sanitize_text_field($row['keyword']),
            'topic' => sanitize_text_field($row['topic']),
            'category' => sanitize_text_field($row['category']),
            'status' => 'Published',
            'post_status' => get_post_status($post_id),
            'post_url' => get_permalink($post_id),
            'edit_url' => get_edit_post_link($post_id, 'raw'),
            'warning' => $image_warning,
            'prompt_mode' => !empty($row['prompt']) ? 'per-post' : ((string)get_option('ppai_custom_prompt','') !== '' ? 'site-custom' : 'default'),
            'queue_remaining' => count($queue),
            'timestamp' => current_time('mysql')
        );
        ppai_history_add($entry);
        update_option('ppai_last_error', '', false);
        return array('status'=>'published','postId'=>$post_id,'title'=>$article['title'],'queueRemaining'=>count($queue),'warning'=>$image_warning);

    } catch (Throwable $e) {
        update_option('ppai_last_error', $e->getMessage(), false);
        error_log('[PPAI] Error: ' . $e->getMessage());
        return new WP_Error('ppai_failed', $e->getMessage());
    } finally {
        delete_transient('ppai_run_lock');
    }
}

<?php
if (!defined('ABSPATH')) exit;

add_action('admin_menu', function () {
    add_menu_page('Gemini SEO Auto Poster', 'Gemini SEO', 'manage_options', 'gamini-seo', 'ppai_admin_panel', 'dashicons-edit-page', 81);
});

function ppai_notice($type, $message) {
    echo '<div class="notice notice-' . esc_attr($type) . ' is-dismissible"><p><strong>' . esc_html($message) . '</strong></p></div>';
}

function ppai_admin_handle_posts() {
    if (!current_user_can('manage_options')) return;

    if (isset($_POST['ppai_save_api'])) {
        check_admin_referer('ppai_save_api');
        update_option('ppai_gamini_api_key', sanitize_text_field($_POST['gamini_api_key'] ?? ''), false);
        update_option('ppai_gemini_model', sanitize_text_field($_POST['ppai_gemini_model'] ?? 'gemini-2.0-flash'), false);
        ppai_notice('success', 'API settings saved.');
    }

    if (isset($_POST['save_custom_prompt'])) {
        check_admin_referer('ppai_save_prompt');
        update_option('ppai_custom_prompt', wp_kses_post($_POST['ppai_custom_prompt'] ?? ''), false);
        ppai_notice('success', 'Custom prompt saved.');
    }

    if (isset($_POST['ppai_enable_cron_submit'])) {
        check_admin_referer('ppai_save_cron');
        $val = !empty($_POST['ppai_enable_cron']);
        update_option('ppai_enable_cron', $val, false);
        ppai_schedule_cron_if_enabled();
        ppai_notice('success', $val ? 'WordPress cron enabled.' : 'WordPress cron disabled.');
    }

    if (isset($_POST['upload_csv']) && !empty($_FILES['csv_file']['tmp_name'])) {
        check_admin_referer('ppai_upload_csv');
        $csv = ppai_parse_csv($_FILES['csv_file']['tmp_name']);
        $mode = sanitize_key($_POST['ppai_csv_mode'] ?? 'smart');
        $skip_published = !empty($_POST['ppai_skip_published']);
        if (empty($csv)) {
            ppai_notice('error', 'CSV has no valid rows. Make sure Keyword column exists.');
        } else {
            $sync = ppai_sync_csv_queue($csv, $mode, $skip_published);
            ppai_notice('success', sprintf(
                'CSV synced. Added: %d, Updated: %d, Removed: %d, Skipped published: %d, CSV duplicates fixed: %d, Queue now: %d rows.',
                $sync['added'], $sync['updated'], $sync['removed'], $sync['skippedPublished'], $sync['duplicatesInCsv'], $sync['queueCount']
            ));
        }
    }

    if (isset($_POST['run_generation_now'])) {
        check_admin_referer('ppai_run_now');
        $result = ppai_run_auto_post();
        if (is_wp_error($result)) ppai_notice('error', $result->get_error_message());
        else ppai_notice($result['status'] === 'published' ? 'success' : 'warning', $result['message'] ?? ('Status: ' . $result['status']));
    }

    if (isset($_POST['ppai_clear_queue'])) {
        check_admin_referer('ppai_clear_queue');
        update_option('ppai_csv_queue', array(), false);
        ppai_notice('success', 'Queue cleared.');
    }

    if (isset($_POST['ppai_clear_history'])) {
        check_admin_referer('ppai_clear_history');
        update_option('ppai_post_history', array(), false);
        update_option('ppai_last_error', '', false);
        ppai_notice('success', 'History and last error cleared.');
    }
}

function ppai_admin_panel() {
    if (!current_user_can('manage_options')) { return; }
    ppai_admin_handle_posts();

    $error = get_option('ppai_last_error', '');
    $queue = get_option('ppai_csv_queue', array());
    if (!is_array($queue)) $queue = array();
    $history = get_option('ppai_post_history', array());
    if (!is_array($history)) $history = array();
    $cron_enabled = (bool) get_option('ppai_enable_cron', false);
    $next_cron = wp_next_scheduled('ppai_auto_post_event');
    $last_csv_sync = get_option('ppai_last_csv_sync', array());
    if (!is_array($last_csv_sync)) $last_csv_sync = array();
    $ajax_nonce = wp_create_nonce('ppai_manual_run');
    ?>
    <style>
      .ppai-wrap{max-width:1280px}.ppai-hero{background:linear-gradient(135deg,#101b31,#0b7c99);color:#fff;border-radius:18px;padding:24px;margin:18px 0;box-shadow:0 18px 55px rgba(0,0,0,.18)}.ppai-hero h1{color:#fff;margin:0 0 6px;font-size:30px}.ppai-hero p{font-size:15px;margin:0;opacity:.9}.ppai-grid{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:18px}.ppai-card{background:#fff;border:1px solid #dcdcde;border-radius:16px;padding:18px;box-shadow:0 10px 30px rgba(0,0,0,.04)}.ppai-card h2{margin-top:0}.ppai-kpis{display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:12px;margin:16px 0}.ppai-kpi{background:#fff;border:1px solid #dcdcde;border-radius:14px;padding:14px}.ppai-kpi strong{display:block;font-size:26px}.ppai-muted{color:#646970}.ppai-actions{display:flex;gap:10px;flex-wrap:wrap;align-items:center}.ppai-table-wrap{max-height:420px;overflow:auto;border:1px solid #dcdcde;border-radius:12px}.ppai-table-wrap table{border:none!important}.ppai-danger{color:#b32d2e}.ppai-field{width:100%;max-width:620px}.ppai-card textarea{width:100%;min-height:200px}.ppai-sync-mode{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:10px;margin:12px 0}.ppai-radio{border:1px solid #dcdcde;border-radius:14px;padding:12px;background:#f8fafc}.ppai-radio strong{display:block}.ppai-radio small{display:block;color:#646970;margin-top:3px}.ppai-sync-status{margin-top:12px;padding:12px;border-radius:14px;background:#f0f6fc;border:1px solid #b6d9ff}.ppai-preview-head{display:flex;justify-content:space-between;align-items:center;gap:10px;flex-wrap:wrap}@media(max-width:900px){.ppai-grid,.ppai-kpis,.ppai-sync-mode{grid-template-columns:1fr}}
    </style>
    <div class="wrap ppai-wrap">
      <div class="ppai-hero">
        <h1>Gemini SEO Auto Poster</h1>
        <p>Reliable CSV queue → Gemini article → WordPress post automation. Queue rows are removed only after successful publishing.</p>
      </div>

      <?php if (!empty($error)): ?>
        <div class="notice notice-error"><p><strong>Last Error:</strong> <?php echo esc_html($error); ?></p></div>
      <?php endif; ?>

      <div class="ppai-kpis">
        <div class="ppai-kpi"><span class="ppai-muted">Queue</span><strong><?php echo esc_html(count($queue)); ?></strong></div>
        <div class="ppai-kpi"><span class="ppai-muted">History</span><strong><?php echo esc_html(count($history)); ?></strong></div>
        <div class="ppai-kpi"><span class="ppai-muted">WP Cron</span><strong><?php echo $cron_enabled ? 'On' : 'Off'; ?></strong></div>
        <div class="ppai-kpi"><span class="ppai-muted">Next Cron</span><strong style="font-size:14px"><?php echo $next_cron ? esc_html(date_i18n('Y-m-d H:i', $next_cron)) : '-'; ?></strong></div>
      </div>

      <div class="ppai-grid">
        <div class="ppai-card">
          <h2>API Settings</h2>
          <form method="post">
            <?php wp_nonce_field('ppai_save_api'); ?>
            <p><label>Gemini API Key<br><input name="gamini_api_key" type="password" value="<?php echo esc_attr(get_option('ppai_gamini_api_key', '')); ?>" class="regular-text ppai-field" autocomplete="off" /></label></p>
            <p><label>Gemini Model<br><input name="ppai_gemini_model" type="text" value="<?php echo esc_attr(get_option('ppai_gemini_model', 'gemini-2.0-flash')); ?>" class="regular-text ppai-field" /></label></p>
            <input type="submit" name="ppai_save_api" class="button button-primary" value="Save API Settings">
          </form>
        </div>

        <div class="ppai-card">
          <h2>Run Controls</h2>
          <div class="ppai-actions">
            <form method="post"><?php wp_nonce_field('ppai_run_now'); ?><input type="submit" name="run_generation_now" class="button button-primary" value="▶ Generate One Now"></form>
            <button id="ppai_start_auto" class="button button-secondary">Start Browser Auto</button>
            <button id="ppai_stop_auto" class="button" style="display:none;">Stop</button>
            <label>Every <input type="number" id="auto_interval" min="10" value="60" style="width:80px;" /> seconds</label>
          </div>
          <div id="ppai_auto_status" style="margin-top:12px;font-weight:700;"></div>
          <hr>
          <form method="post" class="ppai-actions">
            <?php wp_nonce_field('ppai_save_cron'); ?>
            <label><input type="checkbox" name="ppai_enable_cron" value="1" <?php checked($cron_enabled); ?>> Enable WordPress cron every 4 minutes</label>
            <input type="submit" name="ppai_enable_cron_submit" class="button" value="Save Cron">
          </form>
        </div>

        <div class="ppai-card">
          <h2>CSV Auto Update / Queue Sync</h2>
          <p class="ppai-muted">Required: <code>Keyword</code>. Optional: <code>Topic</code>, <code>Category</code>, <code>Tags</code>, <code>image</code>, <code>Backlink</code>. Smart mode updates changed rows and adds only new rows.</p>
          <form method="post" enctype="multipart/form-data">
            <?php wp_nonce_field('ppai_upload_csv'); ?>
            <p><input type="file" name="csv_file" accept=".csv,text/csv" required></p>
            <div class="ppai-sync-mode">
              <label class="ppai-radio"><input type="radio" name="ppai_csv_mode" value="smart" checked> <strong>Smart Update</strong><small>Update existing keywords, append new keywords, keep old queue rows.</small></label>
              <label class="ppai-radio"><input type="radio" name="ppai_csv_mode" value="append"> <strong>Append New Only</strong><small>Add only keywords not already in the queue.</small></label>
              <label class="ppai-radio"><input type="radio" name="ppai_csv_mode" value="mirror"> <strong>Mirror CSV</strong><small>Queue becomes exactly this CSV after duplicate cleanup.</small></label>
              <label class="ppai-radio"><input type="radio" name="ppai_csv_mode" value="replace"> <strong>Replace Queue</strong><small>Clear current queue and load this CSV.</small></label>
            </div>
            <p><label><input type="checkbox" name="ppai_skip_published" value="1" checked> Skip keywords already published in history/post meta</label></p>
            <input type="submit" name="upload_csv" class="button button-primary" value="Sync CSV / Auto Update Queue">
          </form>
          <?php if (!empty($last_csv_sync)): ?>
            <div class="ppai-sync-status">
              <strong>Last CSV Sync:</strong>
              <?php echo esc_html($last_csv_sync['time'] ?? ''); ?> —
              Added <?php echo esc_html($last_csv_sync['added'] ?? 0); ?>,
              Updated <?php echo esc_html($last_csv_sync['updated'] ?? 0); ?>,
              Removed <?php echo esc_html($last_csv_sync['removed'] ?? 0); ?>,
              Skipped Published <?php echo esc_html($last_csv_sync['skippedPublished'] ?? 0); ?>,
              Queue <?php echo esc_html($last_csv_sync['queueCount'] ?? count($queue)); ?>.
            </div>
          <?php endif; ?>
          <form method="post" style="margin-top:12px;" onsubmit="return confirm('Clear all queue rows?')">
            <?php wp_nonce_field('ppai_clear_queue'); ?>
            <input type="submit" name="ppai_clear_queue" class="button" value="Clear Queue">
          </form>
        </div>

        <div class="ppai-card">
          <h2>Custom Prompt</h2>
          <form method="post">
            <?php wp_nonce_field('ppai_save_prompt'); ?>
            <textarea name="ppai_custom_prompt" placeholder="Use $topic and $keyword"><?php echo esc_textarea(get_option('ppai_custom_prompt', '')); ?></textarea>
            <p class="ppai-muted">Leave blank to use the built-in Indian financial SEO prompt.</p>
            <input type="submit" name="save_custom_prompt" class="button button-secondary" value="Save Prompt">
          </form>
        </div>
      </div>

      <div class="ppai-card" style="margin-top:18px;">
        <div class="ppai-preview-head"><h2>Queue Preview</h2><span class="ppai-muted">Smart-sync duplicates are automatically cleaned by Keyword.</span></div>
        <div class="ppai-table-wrap">
          <table class="widefat striped">
            <thead><tr><th>#</th><th>Keyword</th><th>Topic</th><th>Category</th><th>Tags</th><th>Backlink</th></tr></thead>
            <tbody>
              <?php if (empty($queue)): ?>
                <tr><td colspan="6">No queue rows.</td></tr>
              <?php else: $i=1; foreach (array_slice($queue, 0, 200) as $r): ?>
                <tr><td><?php echo esc_html($i++); ?></td><td><?php echo esc_html($r['Keyword'] ?? ''); ?></td><td><?php echo esc_html($r['Topic'] ?? ''); ?></td><td><?php echo esc_html($r['Category'] ?? ''); ?></td><td><?php echo esc_html($r['Tags'] ?? ''); ?></td><td><?php echo esc_html($r['Backlink'] ?? ($r['BacklinkURL'] ?? '')); ?></td></tr>
              <?php endforeach; endif; ?>
            </tbody>
          </table>
        </div>
      </div>

      <div class="ppai-card" style="margin-top:18px;">
        <h2>History</h2>
        <form method="post" onsubmit="return confirm('Clear history and last error?')" style="margin-bottom:12px;">
          <?php wp_nonce_field('ppai_clear_history'); ?>
          <input type="submit" name="ppai_clear_history" class="button" value="Clear History">
        </form>
        <div class="ppai-table-wrap">
          <table class="widefat striped">
            <thead><tr><th>Time</th><th>Post ID</th><th>Title</th><th>Keyword</th><th>Status</th><th>Warning</th></tr></thead>
            <tbody>
              <?php if (empty($history)): ?>
                <tr><td colspan="6">No history yet.</td></tr>
              <?php else: foreach (array_reverse(array_slice($history, -200)) as $h): ?>
                <tr><td><?php echo esc_html($h['timestamp'] ?? ''); ?></td><td><?php echo esc_html($h['post_id'] ?? ''); ?></td><td><?php echo esc_html($h['title'] ?? ''); ?></td><td><?php echo esc_html($h['keyword'] ?? ''); ?></td><td><?php echo esc_html($h['status'] ?? ''); ?></td><td><?php echo esc_html($h['warning'] ?? ''); ?></td></tr>
              <?php endforeach; endif; ?>
            </tbody>
          </table>
        </div>
      </div>
    </div>

    <script>
    document.addEventListener('DOMContentLoaded', function () {
      let intervalId = null;
      const startBtn = document.getElementById('ppai_start_auto');
      const stopBtn = document.getElementById('ppai_stop_auto');
      const intervalInput = document.getElementById('auto_interval');
      const statusBox = document.getElementById('ppai_auto_status');
      const nonce = <?php echo wp_json_encode($ajax_nonce); ?>;
      function triggerAutoPost() {
        statusBox.innerText = 'Running...';
        fetch(ajaxurl, {
          method: 'POST',
          headers: {'Content-Type': 'application/x-www-form-urlencoded'},
          body: new URLSearchParams({ action: 'ppai_run_manual_post', nonce })
        })
        .then(res => res.json())
        .then(data => {
          if (!data.success) throw new Error(data.data && data.data.message ? data.data.message : 'Generation failed');
          statusBox.innerText = '✔ ' + (data.data.title || data.data.message || data.data.status) + ' at ' + new Date().toLocaleTimeString();
        })
        .catch(err => { statusBox.innerText = '❌ ' + err.message; });
      }
      startBtn.addEventListener('click', () => {
        const seconds = Math.max(10, parseInt(intervalInput.value || '60', 10));
        triggerAutoPost();
        intervalId = setInterval(triggerAutoPost, seconds * 1000);
        startBtn.style.display = 'none'; stopBtn.style.display = 'inline-block';
      });
      stopBtn.addEventListener('click', () => {
        clearInterval(intervalId);
        startBtn.style.display = 'inline-block'; stopBtn.style.display = 'none';
        statusBox.innerText = 'Stopped.';
      });
    });
    </script>
    <?php
}

<?php
if (!defined('ABSPATH')) exit;

function ppai_default_prompt($topic, $keyword) {
    return "You are a professional Indian financial blog writer.\n\n" .
        "Use relevant Indian financial references such as NSE, BSE, SEBI, mutual funds, SIPs, ELSS, PPF, NPS, equity markets, and investment instruments familiar to Indian investors. Use INR (₹) as the currency symbol.\n\n" .
        "Write a 1500+ word high-quality SEO blog article on the topic \"{$topic}\". Include the keyword \"{$keyword}\" naturally.\n\n" .
        "Also generate an SEO blog title between 50-60 characters and a meta description between 150-160 characters.\n\n" .
        "Format the output in clean HTML only:\n" .
        "- Begin with one <p> containing only the meta description.\n" .
        "- Follow with one <h1> title.\n" .
        "- Then write the full article using <h2>, <h3>, <p>, <ul>, <ol>, and <li> tags.\n" .
        "Do not use markdown, JSON, emojis, scripts, styles, or explanatory labels like Title: or Meta Description:.";
}

function ppai_generate_article($topic, $keyword, $backlink_url = '') {
    $api_key = trim((string) get_option('ppai_gamini_api_key', ''));
    if ($api_key === '') {
        return new WP_Error('ppai_missing_api_key', 'Gemini API key is missing.');
    }

    $topic = sanitize_text_field($topic);
    $keyword = sanitize_text_field($keyword);
    $custom_prompt = (string) get_option('ppai_custom_prompt', '');
    if ($custom_prompt !== '') {
        $prompt = str_replace(array('$topic', '$keyword'), array($topic, $keyword), $custom_prompt);
    } else {
        $prompt = ppai_default_prompt($topic, $keyword);
    }

    $model = sanitize_text_field(get_option('ppai_gemini_model', 'gemini-2.0-flash'));
    if ($model === '') $model = 'gemini-2.0-flash';
    $endpoint = 'https://generativelanguage.googleapis.com/v1beta/models/' . rawurlencode($model) . ':generateContent?key=' . rawurlencode($api_key);

    $body = wp_json_encode(array(
        'contents' => array(array('parts' => array(array('text' => $prompt))))
    ));

    $response = wp_remote_post($endpoint, array(
        'headers' => array('Content-Type' => 'application/json'),
        'body' => $body,
        'timeout' => 150
    ));

    if (is_wp_error($response)) {
        return new WP_Error('ppai_connection_error', 'Gemini connection error: ' . $response->get_error_message());
    }

    $code = (int) wp_remote_retrieve_response_code($response);
    $json = wp_remote_retrieve_body($response);
    $data = json_decode($json, true);
    if ($code < 200 || $code >= 300) {
        $msg = isset($data['error']['message']) ? $data['error']['message'] : $json;
        return new WP_Error('ppai_gemini_http_error', 'Gemini HTTP ' . $code . ': ' . $msg);
    }

    if (!isset($data['candidates'][0]['content']['parts'][0]['text'])) {
        $error_msg = 'No content returned.';
        if (isset($data['promptFeedback']['blockReason'])) {
            $error_msg .= ' Prompt was blocked: ' . $data['promptFeedback']['blockReason'];
        } elseif (isset($data['error']['message'])) {
            $error_msg .= ' Gemini error: ' . $data['error']['message'];
        }
        return new WP_Error('ppai_no_content', $error_msg);
    }

    $text = $data['candidates'][0]['content']['parts'][0]['text'];
    $text = ppai_clean_text($text);
    $parsed = ppai_extract_title_meta_content($text, $topic);
    $content_with_backlink = ppai_add_backlink($parsed['content'], $keyword, $backlink_url);

    return array(
        'title' => $parsed['title'],
        'content' => "<div class='blog-container'><p>" . esc_html($parsed['meta']) . "</p>" . $content_with_backlink . "</div>",
        'meta' => $parsed['meta']
    );
}

function ppai_clean_text($text) {
    $text = (string) $text;
    $text = preg_replace('/```(?:html)?/i', '', $text);
    $text = str_replace('```', '', $text);
    $text = preg_replace('/<script\b[^>]*>(.*?)<\/script>/is', '', $text);
    $text = preg_replace('/<style\b[^>]*>(.*?)<\/style>/is', '', $text);
    $text = preg_replace('/<img[^>]+>/i', '', $text);
    $text = preg_replace('/Blog Title:\s*/i', '', $text);
    $text = preg_replace('/Meta Description:\s*/i', '', $text);
    $text = preg_replace('/[\x{1F600}-\x{1F64F}\x{1F300}-\x{1F5FF}\x{1F680}-\x{1F6FF}\x{2600}-\x{26FF}]/u', '', $text);
    $text = str_replace(array('*', '#', '_', '~', '`'), '', $text);
    return trim($text);
}

function ppai_extract_title_meta_content($html, $fallback_topic) {
    $html = trim($html);
    $meta = '';
    if (preg_match('/<p\b[^>]*>(.*?)<\/p>/is', $html, $m)) {
        $meta = trim(wp_strip_all_tags($m[1]));
        $html = preg_replace('/<p\b[^>]*>.*?<\/p>/is', '', $html, 1);
    }
    if ($meta === '') $meta = mb_substr(wp_strip_all_tags($html), 0, 155);
    if (mb_strlen($meta) > 160) $meta = mb_substr($meta, 0, 157) . '...';

    $title = ucfirst($fallback_topic);
    if (preg_match('/<h1\b[^>]*>(.*?)<\/h1>/is', $html, $m)) {
        $title = trim(wp_strip_all_tags($m[1]));
        $html = preg_replace('/<h1\b[^>]*>.*?<\/h1>/is', '', $html, 1);
    }
    $title = sanitize_text_field($title ?: ucfirst($fallback_topic));

    $allowed = array(
        'h1'=>array(), 'h2'=>array(), 'h3'=>array(), 'h4'=>array(),
        'p'=>array(), 'ul'=>array(), 'ol'=>array(), 'li'=>array(),
        'strong'=>array(), 'b'=>array(), 'em'=>array(), 'i'=>array(),
        'a'=>array('href'=>array(),'target'=>array(),'rel'=>array()),
        'br'=>array(), 'blockquote'=>array()
    );
    $html = wp_kses($html, $allowed);
    return array('title'=>$title, 'meta'=>sanitize_text_field($meta), 'content'=>$html);
}

function ppai_add_backlink($html, $keyword, $backlink_url) {
    $backlink_url = esc_url($backlink_url);
    $keyword = sanitize_text_field($keyword);
    if ($backlink_url === '' || $keyword === '') return $html;

    $anchor = '<a href="' . esc_url($backlink_url) . '" target="_blank" rel="noopener">' . esc_html($keyword) . '</a>';
    $pattern = '/(?<![\w>])(' . preg_quote($keyword, '/') . ')(?![\w<])/iu';
    if (preg_match($pattern, $html)) {
        return preg_replace($pattern, $anchor, $html, 1);
    }

    if (preg_match_all('/(<p\b[^>]*>.*?<\/p>)/is', $html, $paragraphs) && !empty($paragraphs[0])) {
        $middle = (int) floor(count($paragraphs[0]) / 2);
        $target = $paragraphs[0][$middle];
        $replacement = preg_replace('/<\/p>$/i', ' ' . $anchor . '</p>', $target);
        return preg_replace('/' . preg_quote($target, '/') . '/s', $replacement, $html, 1);
    }

    return $html . '<p>' . $anchor . '</p>';
}

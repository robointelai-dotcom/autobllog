<?php
if (!defined('ABSPATH')) exit;

function ppai_clean_csv_value($value) {
    $value = is_string($value) ? $value : '';
    $value = preg_replace('/^\xEF\xBB\xBF/', '', $value);
    $value = str_replace(array("\xC2\xA0", '“', '”', '‘', '’'), array(' ', '"', '"', "'", "'"), $value);
    return trim($value);
}

function ppai_header_alias($header) {
    $key = strtolower(preg_replace('/\s+/', '', ppai_clean_csv_value($header)));
    $aliases = array(
        'keyword' => 'Keyword', 'keywords' => 'Keyword', 'title' => 'Keyword',
        'topic' => 'Topic', 'subject' => 'Topic',
        'category' => 'Category', 'categories' => 'Category',
        'tags' => 'Tags', 'tag' => 'Tags',
        'image' => 'image', 'imageurl' => 'image', 'image_url' => 'image', 'images' => 'image',
        'backlink' => 'Backlink', 'backlinkurl' => 'Backlink', 'backlink_url' => 'Backlink', 'url' => 'Backlink'
    );
    return isset($aliases[$key]) ? $aliases[$key] : ppai_clean_csv_value($header);
}

function ppai_parse_csv($file) {
    $handle = fopen($file, 'r');
    if (!$handle) return array();

    $header = fgetcsv($handle);
    if (!$header) { fclose($handle); return array(); }
    $header = array_map('ppai_header_alias', $header);

    $data = array();
    while (($row = fgetcsv($handle)) !== false) {
        if (!array_filter($row, function($v){ return trim((string)$v) !== ''; })) continue;
        $assoc = array();
        foreach ($header as $i => $name) {
            $assoc[$name] = isset($row[$i]) ? ppai_clean_csv_value($row[$i]) : '';
        }
        if (empty($assoc['Keyword'])) continue;
        $data[] = array(
            'Keyword' => sanitize_text_field($assoc['Keyword']),
            'Topic' => isset($assoc['Topic']) ? sanitize_text_field($assoc['Topic']) : '',
            'Category' => isset($assoc['Category']) ? sanitize_text_field($assoc['Category']) : '',
            'Tags' => isset($assoc['Tags']) ? sanitize_text_field($assoc['Tags']) : '',
            'image' => isset($assoc['image']) ? esc_url_raw($assoc['image']) : '',
            'Backlink' => isset($assoc['Backlink']) ? esc_url_raw($assoc['Backlink']) : '',
        );
    }
    fclose($handle);
    return $data;
}

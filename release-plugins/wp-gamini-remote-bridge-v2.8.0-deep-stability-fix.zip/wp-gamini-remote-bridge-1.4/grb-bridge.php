<?php
/**
 * Plugin Name: Robointel AutoBlog Remote Bridge
 * Description: Secure REST bridge for the SEM SEO BLOGER / Gemini auto-poster. Provides ping, run, queue and status endpoints for the remote dashboard.
 * Version: 2.8.0
 * Author: robointel
 */
if ( ! defined('ABSPATH') ) { exit; }

define('GRB_BRIDGE_VER','2.8.0');

function grb_ensure_api_key(){
  $existing = trim((string) get_option('grb_api_key', ''));
  if ( $existing === '' ) {
    update_option('grb_api_key', wp_generate_password(40, false, false), false);
  }
}
register_activation_hook(__FILE__, 'grb_ensure_api_key');
// Replacing an already-active plugin may not execute its activation hook.
add_action('init', 'grb_ensure_api_key', 1);

add_action('admin_menu', function(){
  add_menu_page('AutoBlog Bridge','AutoBlog Bridge','manage_options','grb-bridge','grb_settings_page','dashicons-rest-api', 82);
});

function grb_sanitize_api_key( $value ){
  $value = substr(sanitize_text_field((string) $value), 0, 500);
  if ( strlen($value) >= 12 ) { return $value; }

  $existing = trim((string) get_option('grb_api_key', ''));
  if ( function_exists('add_settings_error') ) {
    add_settings_error('grb_api_key', 'grb_api_key_too_short', 'Bridge API key must be at least 12 characters. The previous key was kept.', 'error');
  }
  if ( strlen($existing) >= 12 ) { return $existing; }
  return wp_generate_password(40, false, false);
}

add_action('admin_init', function(){
  register_setting('grb_bridge','grb_api_key', array(
    'type' => 'string',
    'sanitize_callback' => 'grb_sanitize_api_key',
    'default' => ''
  ));
});

function grb_settings_page(){
  if ( ! current_user_can('manage_options') ) { return; }
  $key = get_option('grb_api_key','');
  ?>
  <style>
    .grb-wrap{max-width:1080px}.grb-hero{background:linear-gradient(135deg,#06111f,#172554 55%,#0f766e);border-radius:24px;padding:26px;color:#fff;margin:18px 0;box-shadow:0 22px 70px rgba(2,6,23,.18)}.grb-hero h1{color:#fff;margin:0 0 8px;font-size:32px}.grb-card{background:#fff;border:1px solid #dbe6f3;border-radius:18px;padding:20px;margin-top:16px;box-shadow:0 14px 38px rgba(15,23,42,.07)}.grb-key{font-family:monospace;width:100%;max-width:760px}.grb-routes code{display:inline-block;margin:3px;padding:5px 8px;border-radius:999px;background:#eef6ff}.grb-ok{color:#15803d;font-weight:700}.grb-bad{color:#b91c1c;font-weight:700}
  
.grb-wrap{font-family:Inter,system-ui,-apple-system,BlinkMacSystemFont,"Segoe UI",sans-serif}.grb-hero{background:radial-gradient(620px 230px at 12% 0%,rgba(0,229,255,.26),transparent 60%),radial-gradient(520px 220px at 92% 10%,rgba(124,58,237,.28),transparent 62%),linear-gradient(135deg,#030712,#081A32 58%,#0F766E)!important;border:1px solid rgba(0,229,255,.28);box-shadow:0 30px 100px rgba(0,0,0,.18),0 0 60px rgba(0,229,255,.1)!important}.grb-hero h1{font-size:38px!important;letter-spacing:-.05em}.grb-card{border-radius:24px!important;border:1px solid #d8e7fb!important;box-shadow:0 18px 48px rgba(15,23,42,.08)!important}.grb-routes code{border:1px solid #dbeafe;background:linear-gradient(180deg,#fff,#eff6ff)!important}.button-primary{background:linear-gradient(135deg,#00A9C8,#0F766E)!important;border:none!important;border-radius:10px!important;font-weight:700}.grb-key{border-radius:12px!important;padding:9px 12px!important}
</style>
  <div class="wrap grb-wrap">
    <div class="grb-hero"><h1>Remote Controller Pro Bridge</h1><p>World-class secure connection between Remote Controller dashboard, CSV queue, Gemini settings and WordPress publishing.</p></div>
    <?php if ( ! function_exists('ppai_run_auto_post') ): ?>
      <div class="notice notice-error"><p><strong>Warning:</strong> SEM SEO BLOGER is not active. The dashboard can ping this bridge, but posting cannot run.</p></div>
    <?php else: ?>
      <div class="notice notice-success"><p><strong>Ready:</strong> SEM SEO BLOGER is active and queue endpoints are available.</p></div>
    <?php endif; ?>
    <div class="grb-card">
      <h2>Bridge API Key</h2>
      <p>Copy this key into the dashboard. Keep it private. You can also rotate this key from the dashboard API Key Manager.</p>
      <form method="post" action="options.php">
        <?php settings_fields('grb_bridge'); do_settings_sections('grb_bridge'); ?>
        <input name="grb_api_key" id="grb_api_key" type="text" class="regular-text grb-key" value="<?php echo esc_attr( $key ); ?>" autocomplete="off" />
        <?php submit_button('Save Bridge Key'); ?>
      </form>
    </div>
    <div class="grb-card grb-routes">
      <h2>Endpoint Base</h2>
      <p><b>Pretty REST:</b> <code><?php echo esc_html( home_url('/wp-json/grb/v1') ); ?></code></p>
      <p><b>Safe fallback REST:</b> <code><?php echo esc_html( add_query_arg('rest_route','/grb/v1', home_url('/')) ); ?></code></p>
      <p class="description">v18.3 dashboard uses the safe fallback REST format by default. This fixes many server/Nginx/LiteSpeed cases where /wp-json returns an HTML 404 page.</p>
      <p><code>/ping</code><code>/run</code><code>/settings</code><code>/prompt</code><code>/prompt/generate</code><code>/settings/test-gemini</code><code>/queue</code><code>/queue/sync</code><code>/queue/append</code><code>/queue/clear</code><code>/history</code><code>/diagnostics</code><code>/status</code><code>/plugins</code><code>/plugins/action</code><code>/plugins/upload</code></p>
    </div>
  </div>
  <?php
}

class GRB_Bridge_Rest {
  private static function check_key( $request ){
    $hdr = (string) $request->get_header('x-api-key');
    $key = (string) get_option('grb_api_key','');
    if ( $key === '' || $hdr === '' ) { return false; }
    return function_exists('hash_equals') ? hash_equals($key, $hdr) : $key === $hdr;
  }

  private static function auth_or_error( $request ){
    if ( self::check_key($request) ) { return true; }
    return new WP_Error('grb_unauthorized','Unauthorized', array('status'=>401));
  }

  public static function permission( $request ){
    return self::auth_or_error($request);
  }

  private static function acquire_option_lock( $name, $ttl = 900 ){
    $ttl = max(60, (int) $ttl);
    $now = time();
    $token = function_exists('wp_generate_uuid4') ? wp_generate_uuid4() : uniqid('grb_', true);
    $payload = array('token'=>$token, 'created'=>$now, 'expires'=>$now + $ttl);
    if ( add_option($name, $payload, '', 'no') ) { return $token; }

    $existing = get_option($name, array());
    $expires = is_array($existing) ? (int)($existing['expires'] ?? 0) : 0;
    if ( $expires > 0 && $expires < $now ) {
      delete_option($name);
      if ( add_option($name, $payload, '', 'no') ) { return $token; }
    }
    return false;
  }

  private static function release_option_lock( $name, $token ){
    $existing = get_option($name, array());
    if ( is_array($existing) && isset($existing['token']) && hash_equals((string)$existing['token'], (string)$token) ) {
      delete_option($name);
    }
  }

  private static function queue(){
    $queue = get_option('ppai_csv_queue', array());
    return is_array($queue) ? array_values($queue) : array();
  }


  private static function mask_secret( $value ){
    $value = (string) $value;
    if ( $value === '' ) { return ''; }
    $len = strlen($value);
    if ( $len <= 8 ) { return str_repeat('•', $len); }
    return substr($value, 0, 4) . str_repeat('•', max(4, $len - 8)) . substr($value, -4);
  }

  private static function redact_secret_text( $value, $max_length = 1200 ){
    if ( function_exists('ppai_redact_secret_text') ) { return ppai_redact_secret_text($value, $max_length); }
    $value = (string) $value;
    $value = preg_replace('/((?:[?&]|\b)(?:key|api_key|apikey|geminiApiKey|bridgeApiKey|token|access_token|secret|password)=)[^&\s,;]*/i', '$1[REDACTED]', $value);
    $value = preg_replace('/(["\'](?:key|api[_-]?key|apikey|geminiApiKey|bridgeApiKey|token|access[_-]?token|secret|password)["\']\s*:\s*["\'])[^"\']*(["\'])/i', '$1[REDACTED]$2', $value);
    return substr($value, 0, max(100, (int)$max_length));
  }

  private static function default_gemini_model(){
    return function_exists('ppai_default_gemini_model') ? ppai_default_gemini_model() : 'gemini-2.5-flash';
  }

  private static function resolved_gemini_model( $model = '' ){
    if ( function_exists('ppai_resolve_gemini_model') ) {
      return ppai_resolve_gemini_model($model);
    }
    $model = substr(sanitize_text_field((string) $model), 0, 120);
    $retired = array('gemini-2.0-flash','gemini-2.0-flash-001','gemini-2.0-flash-lite','gemini-2.0-flash-lite-001');
    return $model === '' || in_array(strtolower($model), $retired, true) ? self::default_gemini_model() : $model;
  }

  private static function default_prompt_template(){
    if ( function_exists('ppai_default_prompt') ) {
      $sample = ppai_default_prompt('$topic', '$keyword');
      if ( is_string($sample) && $sample !== '' ) { return $sample; }
    }
    return "You are an expert SEO blog writer and careful content editor.\n\n" .
      "Write a complete, accurate, useful SEO article about \"$topic\". Include the primary keyword \"$keyword\" naturally without keyword stuffing.\n\n" .
      "Return clean HTML only. Start with one <p> meta description, then one <h1> SEO title, then the full article using <h2>, <h3>, <p>, <ul>, <ol>, and <li>.\n" .
      "Do not invent facts or claims. For high-stakes topics provide educational information only. Do not use markdown, JSON, scripts, styles, emojis, or labels like Title: or Meta Description:.";
  }

  private static function prompt_warnings( $prompt ){
    $warnings = array();
    $plain = (string) $prompt;
    if ( trim($plain) === '' ) { return $warnings; }
    if ( strpos($plain, '$topic') === false && strpos($plain, '{{topic}}') === false && strpos($plain, '{topic}') === false ) {
      $warnings[] = 'Prompt does not contain $topic or {{topic}} placeholder.';
    }
    if ( strpos($plain, '$keyword') === false && strpos($plain, '{{keyword}}') === false && strpos($plain, '{keyword}') === false ) {
      $warnings[] = 'Prompt does not contain $keyword or {{keyword}} placeholder.';
    }
    if ( stripos($plain, 'html') === false ) {
      $warnings[] = 'Prompt does not mention HTML output; plugin can still clean output, but HTML instruction is recommended.';
    }
    return $warnings;
  }

  private static function render_prompt_preview( $prompt, $topic = 'sample topic', $keyword = 'sample keyword', $backlink = 'https://example.com' ){
    $prompt = (string) $prompt;
    if ( trim($prompt) === '' ) { $prompt = self::default_prompt_template(); }
    $replacements = array(
      '$topic' => $topic, '{{topic}}' => $topic, '{topic}' => $topic,
      '$keyword' => $keyword, '{{keyword}}' => $keyword, '{keyword}' => $keyword,
      '$backlink' => $backlink, '{{backlink}}' => $backlink, '{backlink}' => $backlink,
    );
    return strtr($prompt, $replacements);
  }

  private static function prompt_payload( $topic = '', $keyword = '' ){
    $custom = (string) get_option('ppai_custom_prompt','');
    $default = self::default_prompt_template();
    $active = $custom !== '' ? $custom : $default;
    $topic = sanitize_text_field((string)($topic !== '' ? $topic : 'open demat account'));
    $keyword = sanitize_text_field((string)($keyword !== '' ? $keyword : 'open demat account'));
    return array(
      'ok' => true,
      'site' => home_url(),
      'bridgeVersion' => GRB_BRIDGE_VER,
      'customPromptSet' => $custom !== '',
      'customPromptLength' => strlen($custom),
      'customPrompt' => $custom,
      'defaultPrompt' => $default,
      'activePromptPreview' => self::render_prompt_preview($active, $topic, $keyword),
      'warnings' => self::prompt_warnings($custom !== '' ? $custom : $default),
      'variables' => array('$topic', '$keyword', '$backlink', '{{topic}}', '{{keyword}}', '{{backlink}}'),
      'maxLength' => 20000,
    );
  }

  private static function update_prompt_from_request( $request ){
    $p = $request->get_json_params();
    if ( ! is_array($p) ) { $p = array(); }
    if ( ! empty($p['clearCustomPrompt']) ) {
      update_option('ppai_custom_prompt', '', false);
      $payload = self::prompt_payload($p['previewTopic'] ?? '', $p['previewKeyword'] ?? '');
      $payload['changed'] = array('customPromptCleared');
      return $payload;
    }
    if ( ! array_key_exists('customPrompt', $p) ) {
      return new WP_Error('grb_no_prompt', 'customPrompt is required.', array('status'=>400));
    }
    $prompt = wp_kses_post((string) $p['customPrompt']);
    if ( strlen($prompt) > 20000 ) {
      return new WP_Error('grb_prompt_too_long', 'Prompt is too long. Max 20000 characters.', array('status'=>413));
    }
    update_option('ppai_custom_prompt', $prompt, false);
    $payload = self::prompt_payload($p['previewTopic'] ?? '', $p['previewKeyword'] ?? '');
    $payload['changed'] = array('customPrompt');
    return $payload;
  }

  private static function settings_payload(){
    $history = get_option('ppai_post_history', array());
    if ( ! is_array($history) ) { $history = array(); }
    $last_sync = get_option('ppai_last_csv_sync', array());
    if ( ! is_array($last_sync) ) { $last_sync = array(); }
    $bridge_key = (string) get_option('grb_api_key','');
    $gemini_key = (string) get_option('ppai_gamini_api_key','');
    $prompt = (string) get_option('ppai_custom_prompt','');
    $stored_model = (string) get_option('ppai_gemini_model','');
    $model = self::resolved_gemini_model($stored_model);
    if ($stored_model !== $model) { update_option('ppai_gemini_model', $model, false); }
    return array(
      'ok' => true,
      'site' => home_url(),
      'bridgeVersion' => GRB_BRIDGE_VER,
      'pluginActive' => function_exists('ppai_run_auto_post'),
      'bridgeKeySet' => $bridge_key !== '',
      'bridgeKeyMasked' => self::mask_secret($bridge_key),
      'geminiKeySet' => $gemini_key !== '',
      'geminiKeyMasked' => self::mask_secret($gemini_key),
      'geminiModel' => $model,
      'customPromptSet' => $prompt !== '',
      'customPromptLength' => strlen($prompt),
      'customPromptPreview' => $prompt !== '' ? substr(wp_strip_all_tags($prompt), 0, 180) : '',
      'promptRoute' => home_url('/wp-json/grb/v1/prompt'),
      'queueCount' => count(self::queue()),
      'lastCsvSync' => $last_sync,
      'lastError' => self::redact_secret_text(get_option('ppai_last_error', '')),
      'cronEnabled' => (bool) get_option('ppai_enable_cron', false),
      'wpCronScheduled' => (bool) wp_next_scheduled('ppai_auto_post_event'),
      'historyCount' => count($history),
    );
  }

  private static function update_settings_from_request( $request ){
    $p = $request->get_json_params();
    if ( ! is_array($p) ) { $p = array(); }

    // Validate the complete request before changing any option. This prevents a
    // partial API-key rotation when a later field (for example a long prompt)
    // is invalid.
    $updates = array();
    $changed = array();

    if ( array_key_exists('bridgeApiKey', $p) ) {
      $new = substr(sanitize_text_field((string) $p['bridgeApiKey']), 0, 500);
      if ( strlen($new) < 12 ) {
        return new WP_Error('grb_bad_bridge_key', 'Bridge API key must be at least 12 characters.', array('status'=>400));
      }
      $updates['bridgeApiKey'] = $new;
      $changed[] = 'bridgeApiKey';
    }

    if ( ! empty($p['clearGeminiApiKey']) ) {
      $updates['geminiApiKey'] = '';
      $changed[] = 'geminiApiKeyCleared';
    } elseif ( array_key_exists('geminiApiKey', $p) ) {
      $new = substr(sanitize_text_field((string) $p['geminiApiKey']), 0, 3000);
      if ( $new !== '' ) {
        $updates['geminiApiKey'] = $new;
        $changed[] = 'geminiApiKey';
      }
    }

    if ( array_key_exists('geminiModel', $p) ) {
      $model = self::resolved_gemini_model($p['geminiModel']);
      if ( $model !== '' ) {
        $updates['geminiModel'] = $model;
        $changed[] = 'geminiModel';
      }
    }

    if ( ! empty($p['clearCustomPrompt']) ) {
      $updates['customPrompt'] = '';
      $changed[] = 'customPromptCleared';
    } elseif ( array_key_exists('customPrompt', $p) ) {
      $prompt = wp_kses_post((string) $p['customPrompt']);
      if ( strlen($prompt) > 20000 ) {
        return new WP_Error('grb_prompt_too_long', 'Prompt is too long. Max 20000 characters.', array('status'=>413));
      }
      $updates['customPrompt'] = $prompt;
      $changed[] = 'customPrompt';
    }

    if ( array_key_exists('cronEnabled', $p) ) {
      $updates['cronEnabled'] = (bool) $p['cronEnabled'];
      $changed[] = 'cronEnabled';
    }

    if ( array_key_exists('bridgeApiKey', $updates) ) update_option('grb_api_key', $updates['bridgeApiKey'], false);
    if ( array_key_exists('geminiApiKey', $updates) ) update_option('ppai_gamini_api_key', $updates['geminiApiKey'], false);
    if ( array_key_exists('geminiModel', $updates) ) update_option('ppai_gemini_model', $updates['geminiModel'], false);
    if ( array_key_exists('customPrompt', $updates) ) update_option('ppai_custom_prompt', $updates['customPrompt'], false);
    if ( array_key_exists('cronEnabled', $updates) ) {
      update_option('ppai_enable_cron', $updates['cronEnabled'], false);
      if ( function_exists('ppai_schedule_cron_if_enabled') ) { ppai_schedule_cron_if_enabled(); }
    }

    $payload = self::settings_payload();
    $payload['changed'] = $changed;
    return $payload;
  }

  private static function row_value( $row, $names ){
    if ( ! is_array($row) ) { return ''; }
    foreach ( $names as $name ) { if ( isset($row[$name]) ) { return $row[$name]; } }
    $map = array();
    foreach ( $row as $k => $v ) { $map[strtolower(preg_replace('/[\s_\-]+/', '', (string) $k))] = $v; }
    foreach ( $names as $name ) {
      $key = strtolower(preg_replace('/[\s_\-]+/', '', (string) $name));
      if ( array_key_exists($key, $map) ) { return $map[$key]; }
    }
    return '';
  }

  private static function sanitize_row( $row ){
    $keyword = sanitize_text_field((string) self::row_value($row, array('Keyword','keyword','Keywords','title','Title')));
    $topic = sanitize_text_field((string) self::row_value($row, array('Topic','topic','Subject','subject')));
    $category = sanitize_text_field((string) self::row_value($row, array('Category','category','Categories')));
    $tags = sanitize_text_field((string) self::row_value($row, array('Tags','tags','Tag','tag')));
    $image = esc_url_raw((string) self::row_value($row, array('image','Image','image_url','ImageURL','imageUrl','featured_image','Featured Image')));
    $backlink = esc_url_raw((string) self::row_value($row, array('Backlink','backlink','BacklinkURL','backlink_url','backlinkUrl','URL','url','link')));
    $prompt = wp_kses_post((string) self::row_value($row, array('Prompt','prompt','CustomPrompt','custom_prompt','PostPrompt','post_prompt','AI Prompt','ai_prompt')));
    if ( strlen($prompt) > 5000 ) { $prompt = substr($prompt, 0, 5000); }
    if ( $topic === '' ) { $topic = $keyword; }
    if ( $category === '' ) { $category = 'Uncategorized'; }
    return array(
      'Keyword'  => $keyword,
      'Topic'    => $topic,
      'Category' => $category,
      'Tags'     => $tags,
      'image'    => $image,
      'Backlink' => $backlink,
      'Prompt' => $prompt,
    );
  }


  private static function row_key( $row ){
    $kw = isset($row['Keyword']) ? (string) $row['Keyword'] : '';
    $kw = wp_strip_all_tags($kw);
    $kw = preg_replace('/\\s+/u', ' ', trim($kw));
    return function_exists('mb_strtolower') ? mb_strtolower($kw, 'UTF-8') : strtolower($kw);
  }

  private static function published_keys(){
    $keys = array();
    $history = get_option('ppai_post_history', array());
    if ( is_array($history) ) {
      foreach ($history as $entry) {
        if ( ! empty($entry['keyword']) ) {
          $k = self::row_key(array('Keyword'=>$entry['keyword']));
          if ( $k !== '' ) { $keys[$k] = true; }
        }
      }
    }
    $posts = get_posts(array(
      'post_type' => 'post',
      'post_status' => array('publish','draft','pending','future'),
      'posts_per_page' => 1000,
      'fields' => 'ids',
      'meta_query' => array('relation'=>'OR', array('key'=>'rank_math_focus_keyword','compare'=>'EXISTS'), array('key'=>'_ppai_queue_keyword','compare'=>'EXISTS')),
      'no_found_rows' => true,
    ));
    foreach ($posts as $post_id) {
      $kw = get_post_meta($post_id, 'rank_math_focus_keyword', true);
      if ( $kw === '' ) { $kw = get_post_meta($post_id, '_ppai_queue_keyword', true); }
      $kw = self::row_key(array('Keyword'=>$kw));
      if ( $kw !== '' ) { $keys[$kw] = true; }
    }
    return $keys;
  }


  private static function enrich_history_item( $entry ){
    $entry = is_array($entry) ? $entry : array();
    $post_id = isset($entry['post_id']) ? absint($entry['post_id']) : 0;
    if ( $post_id > 0 ) {
      $post = get_post($post_id);
      if ( $post ) {
        if ( empty($entry['title']) ) { $entry['title'] = get_the_title($post_id); }
        $entry['post_status'] = get_post_status($post_id);
        $entry['post_url'] = get_permalink($post_id);
        $entry['edit_url'] = get_edit_post_link($post_id, 'raw');
        $entry['modified'] = get_the_modified_date('Y-m-d H:i:s', $post_id);
        $entry['created'] = get_the_date('Y-m-d H:i:s', $post_id);
      }
    }
    if ( empty($entry['timestamp']) && ! empty($entry['created']) ) { $entry['timestamp'] = $entry['created']; }
    return $entry;
  }

  private static function history_from_posts( $limit = 100 ){
    $ids = get_posts(array(
      'post_type'      => 'post',
      'post_status'    => array('publish','draft','pending','future'),
      'posts_per_page' => max(1, min(500, absint($limit))),
      'fields'         => 'ids',
      'orderby'        => 'modified',
      'order'          => 'DESC',
      'meta_query'     => array(
        'relation' => 'OR',
        array('key' => '_ppai_queue_keyword', 'compare' => 'EXISTS'),
        array('key' => 'rank_math_focus_keyword', 'compare' => 'EXISTS'),
        array('key' => '_ppai_csv_row_source', 'compare' => 'EXISTS')
      ),
      'no_found_rows'  => true,
    ));
    $rows = array();
    foreach ($ids as $post_id) {
      $kw = get_post_meta($post_id, '_ppai_queue_keyword', true);
      if ($kw === '') { $kw = get_post_meta($post_id, 'rank_math_focus_keyword', true); }
      $rows[] = array(
        'post_id' => $post_id,
        'title' => get_the_title($post_id),
        'keyword' => sanitize_text_field($kw),
        'status' => ucfirst((string) get_post_status($post_id)),
        'post_status' => get_post_status($post_id),
        'post_url' => get_permalink($post_id),
        'edit_url' => get_edit_post_link($post_id, 'raw'),
        'queue_remaining' => count(self::queue()),
        'timestamp' => get_the_modified_date('Y-m-d H:i:s', $post_id),
        'created' => get_the_date('Y-m-d H:i:s', $post_id),
        'source' => 'post-meta-scan'
      );
    }
    return $rows;
  }

  private static function history_payload( $limit = 100 ){
    $limit = max(1, min(500, absint($limit)));
    $saved_history = get_option('ppai_post_history', array());
    if ( ! is_array($saved_history) ) { $saved_history = array(); }
    $history = array_reverse(array_slice($saved_history, -1 * $limit));
    $history = array_map(array(__CLASS__, 'enrich_history_item'), $history);

    // Repair/fallback: if old plugin did not save ppai_post_history, rebuild history from post meta.
    $scanned = self::history_from_posts($limit);
    $by_id = array();
    foreach ($history as $row) {
      $pid = isset($row['post_id']) ? absint($row['post_id']) : 0;
      if ($pid) { $by_id[$pid] = $row; }
      else { $by_id['hist_' . count($by_id)] = $row; }
    }
    foreach ($scanned as $row) {
      $pid = isset($row['post_id']) ? absint($row['post_id']) : 0;
      if ($pid && ! isset($by_id[$pid])) { $by_id[$pid] = $row; }
    }
    $history = array_values($by_id);
    usort($history, function($a,$b){ return strcmp((string)($b['timestamp'] ?? $b['created'] ?? ''), (string)($a['timestamp'] ?? $a['created'] ?? '')); });
    $history = array_slice($history, 0, $limit);

    return array(
      'ok' => true,
      'site' => home_url(),
      'bridgeVersion' => GRB_BRIDGE_VER,
      'historyCount' => count($history),
      'savedHistoryCount' => count($saved_history),
      'history' => array_values($history),
      'queueCount' => count(self::queue()),
      'lastCsvSync' => get_option('ppai_last_csv_sync', array()),
      'lastError' => self::redact_secret_text(get_option('ppai_last_error', ''))
    );
  }


  private static function safe_prompt_builder( $p = array() ){
    $focus = sanitize_text_field((string)($p['focus'] ?? 'SEO blog article'));
    $business = sanitize_text_field((string)($p['businessType'] ?? get_bloginfo('name')));
    $audience = sanitize_text_field((string)($p['audience'] ?? 'readers and potential customers'));
    $language = sanitize_text_field((string)($p['language'] ?? 'English'));
    $tone = sanitize_text_field((string)($p['tone'] ?? 'professional, helpful, trustworthy and easy to understand'));
    $word_count = max(700, min(5000, absint($p['wordCount'] ?? 1500)));
    $compliance = sanitize_key((string)($p['compliance'] ?? 'general'));
    $extra = substr(sanitize_textarea_field((string)($p['extraRules'] ?? '')), 0, 2000);
    $include_faq = ! array_key_exists('includeFaq', $p) || (bool) $p['includeFaq'];
    $include_table = ! empty($p['includeTable']);
    $include_conclusion = ! array_key_exists('includeConclusion', $p) || (bool) $p['includeConclusion'];
    $include_backlink = ! array_key_exists('includeBacklink', $p) || (bool) $p['includeBacklink'];

    $compliance_block = "Safety restrictions:\n- Do not invent facts, statistics, awards, prices, legal claims, medical claims, or financial guarantees.\n- If exact data is unknown, use cautious wording and avoid fake numbers.\n- Avoid harmful, illegal, deceptive, hateful, or adult content.";
    if ($compliance === 'finance') {
      $compliance_block = "Financial / SEBI-safe restrictions:\n- Write educational information only. Do not give personalised investment advice.\n- Do not promise, guarantee, or imply assured returns, sure profit, zero risk, or future performance.\n- Mention risk, volatility, costs, taxes, eligibility, and that readers should verify details or consult a qualified adviser where relevant.\n- Do not tell readers to buy, sell, hold, or trade any specific stock, fund, or security.\n- Use Indian context only when relevant, such as SEBI, NSE, BSE, demat, brokerage, SIP, mutual funds, taxation, and INR (₹).";
    } elseif ($compliance === 'medical') {
      $compliance_block = "Health content restrictions:\n- Write educational information only. Do not diagnose, prescribe, or claim guaranteed results.\n- Tell readers to consult a qualified professional for personal medical decisions.\n- Avoid unsafe dosage, treatment, or emergency claims.";
    }

    return "You are an expert SEO blog writer and careful content editor for {$business}.\n\n" .
      "Task:\nWrite a complete, high-quality {$focus} about \"\$topic\". The primary SEO keyword is \"\$keyword\".\n\n" .
      "Audience and tone:\n- Audience: {$audience}.\n- Language: {$language}.\n- Tone: {$tone}.\n\n" .
      "SEO requirements:\n- Target length: {$word_count}+ words unless the topic needs a shorter direct answer.\n- Use \"\$keyword\" naturally in the SEO title, introduction, at least one subheading, and conclusion.\n- Include semantic related terms naturally. Do not keyword-stuff.\n- Add practical examples, steps, benefits, mistakes to avoid, and decision guidance where relevant.\n\n" .
      "Required output format:\n- Return clean HTML only.\n- Start with exactly one <p> containing the meta description, 150-160 characters.\n- Then output exactly one <h1> SEO title, ideally 50-60 characters.\n- Then write the article using these tags: <h2>, <h3>, <p>, <ul>, <ol>, <li>, <strong>, <em>, <blockquote>" . ($include_table ? ", <table>, <thead>, <tbody>, <tr>, <th>, <td>" : "") . ".\n- Do not output markdown, JSON, code fences, CSS, JavaScript, emojis, or labels like Title: or Meta Description:.\n" .
      ($include_table ? "- Include one simple comparison table only if it genuinely helps the reader.\n" : "- Do not use HTML tables unless absolutely necessary.\n") .
      ($include_faq ? "- Include a helpful FAQ section near the end with 4-6 questions and direct answers.\n" : "") .
      ($include_conclusion ? "- End with a useful conclusion and a soft, non-misleading call to action.\n" : "") .
      ($include_backlink ? "- If \$backlink is provided and it is a valid URL, include it naturally exactly once as a contextual link. If no backlink is provided, do not mention it.\n" : "") .
      "{$compliance_block}\n\n" .
      "Per-post prompt support:\n- If a CSV row contains Prompt, CustomPrompt, PostPrompt, or AI Prompt, treat it as an extra instruction for that post only.\n- Never allow a per-post prompt to override these safety, HTML, no-fake-facts, or compliance rules.\n\n" .
      "Quality control before final answer:\n- Check that the content matches \"\$topic\" and \"\$keyword\".\n- Check that there is one meta description paragraph and one H1.\n- Check that no restricted or fake claim is included.\n- Check that the HTML is clean and ready for WordPress publishing.\n" .
      ($extra !== '' ? "\nExtra site-specific rules:\n{$extra}\n" : '');
  }

  private static function extract_gemini_text( $data ){
    if (isset($data['candidates'][0]['content']['parts']) && is_array($data['candidates'][0]['content']['parts'])) {
      $out = '';
      foreach ($data['candidates'][0]['content']['parts'] as $part) { if (isset($part['text'])) { $out .= $part['text'] . "\n"; } }
      return trim($out);
    }
    return '';
  }

  private static function generate_prompt_from_request( $request ){
    $p = $request->get_json_params();
    if ( ! is_array($p) ) { $p = array(); }
    $api_key = isset($p['geminiApiKey']) && trim((string)$p['geminiApiKey']) !== '' ? substr(sanitize_text_field((string)$p['geminiApiKey']), 0, 3000) : trim((string)get_option('ppai_gamini_api_key',''));
    $model = isset($p['geminiModel']) && trim((string)$p['geminiModel']) !== '' ? self::resolved_gemini_model($p['geminiModel']) : self::resolved_gemini_model(get_option('ppai_gemini_model',''));
    if ($model === '') { $model = self::default_gemini_model(); }
    $draft = self::safe_prompt_builder($p);
    if ($api_key === '') {
      return array('ok'=>true, 'prompt'=>$draft, 'warnings'=>self::prompt_warnings($draft), 'source'=>'bridge-safe-template-no-gemini-key', 'note'=>'Gemini API key is missing on this WordPress site. Save a Gemini key or paste a temporary key to generate with AI.', 'bridgeVersion'=>GRB_BRIDGE_VER);
    }
    $master = "You are building a reusable WordPress Gemini article-generation prompt. Return ONLY the final prompt text. Do not write an article. Do not use markdown fences. The final prompt MUST keep variables exactly as variables: $" . "topic, $" . "keyword, and $" . "backlink. It must be safe for automatic blog generation, force clean HTML output, and include strict restrictions against fake facts, guarantees, harmful claims, markdown, scripts, styles and keyword stuffing. Improve this draft without removing safety rules:\n\n" . $draft;
    $endpoint = 'https://generativelanguage.googleapis.com/v1beta/models/' . rawurlencode($model) . ':generateContent?key=' . rawurlencode($api_key);
    $body = wp_json_encode(array(
      'contents'=>array(array('parts'=>array(array('text'=>$master)))),
      'generationConfig'=>array('temperature'=>0.35, 'topP'=>0.8, 'maxOutputTokens'=>4096)
    ));
    $response = wp_remote_post($endpoint, array('headers'=>array('Content-Type'=>'application/json'), 'body'=>$body, 'timeout'=>60));
    if (is_wp_error($response)) { return new WP_Error('grb_prompt_ai_connection', 'Gemini connection error: ' . self::redact_secret_text($response->get_error_message()), array('status'=>502)); }
    $code = (int) wp_remote_retrieve_response_code($response);
    $raw = wp_remote_retrieve_body($response);
    $data = json_decode($raw, true);
    if ($code < 200 || $code >= 300) {
      $msg = isset($data['error']['message']) ? $data['error']['message'] : $raw;
      return new WP_Error('grb_prompt_ai_http', 'Gemini HTTP ' . $code . ': ' . self::redact_secret_text($msg), array('status'=>400));
    }
    $prompt = self::extract_gemini_text($data);
    $prompt = preg_replace('/^```(?:text|markdown)?/i', '', $prompt);
    $prompt = preg_replace('/```$/', '', $prompt);
    $prompt = trim($prompt);
    if ($prompt === '') { return new WP_Error('grb_prompt_ai_empty', 'Gemini returned empty prompt.', array('status'=>502)); }
    return array('ok'=>true, 'prompt'=>$prompt, 'warnings'=>self::prompt_warnings($prompt), 'source'=>'bridge-gemini-saved-key', 'model'=>$model, 'bridgeVersion'=>GRB_BRIDGE_VER);
  }

  private static function test_gemini_key( $request ){
    $p = $request->get_json_params();
    if ( ! is_array($p) ) { $p = array(); }
    $api_key = isset($p['geminiApiKey']) && trim((string)$p['geminiApiKey']) !== '' ? substr(sanitize_text_field((string)$p['geminiApiKey']), 0, 3000) : trim((string)get_option('ppai_gamini_api_key',''));
    $model = isset($p['geminiModel']) && trim((string)$p['geminiModel']) !== '' ? self::resolved_gemini_model($p['geminiModel']) : self::resolved_gemini_model(get_option('ppai_gemini_model',''));
    if ( $model === '' ) { $model = self::default_gemini_model(); }
    if ( $api_key === '' ) { return new WP_Error('grb_missing_gemini_key', 'Gemini API key is missing.', array('status'=>400)); }

    $endpoint = 'https://generativelanguage.googleapis.com/v1beta/models/' . rawurlencode($model) . ':generateContent?key=' . rawurlencode($api_key);
    $body = wp_json_encode(array('contents'=>array(array('parts'=>array(array('text'=>'Reply with exactly: OK'))))));
    $response = wp_remote_post($endpoint, array('headers'=>array('Content-Type'=>'application/json'), 'body'=>$body, 'timeout'=>30));
    if ( is_wp_error($response) ) { return new WP_Error('grb_gemini_connection', 'Gemini connection error: ' . self::redact_secret_text($response->get_error_message()), array('status'=>502)); }
    $code = (int) wp_remote_retrieve_response_code($response);
    $raw = wp_remote_retrieve_body($response);
    $data = json_decode($raw, true);
    if ( $code < 200 || $code >= 300 ) {
      $msg = isset($data['error']['message']) ? $data['error']['message'] : $raw;
      return new WP_Error('grb_gemini_http', 'Gemini HTTP ' . $code . ': ' . self::redact_secret_text($msg), array('status'=>400));
    }
    $reply = self::extract_gemini_text($data);
    if ( trim($reply) === '' ) {
      return new WP_Error('grb_gemini_empty', 'Gemini accepted the request but returned no usable text.', array('status'=>502));
    }
    return array('ok'=>true, 'message'=>'Gemini key test passed', 'model'=>$model, 'replyPreview'=>substr(wp_strip_all_tags($reply),0,80), 'usedSavedKey'=> ! isset($p['geminiApiKey']) || trim((string)$p['geminiApiKey']) === '');
  }

  private static function sync_queue( $items, $mode = 'smart', $skip_published = false ){
    // Use the publisher's single queue implementation when v5.6+ is active.
    // This also applies its atomic queue lock so simultaneous dashboard/WordPress
    // CSV updates cannot overwrite each other.
    if ( function_exists('ppai_sync_csv_queue') ) {
      return ppai_sync_csv_queue($items, $mode, $skip_published);
    }
    $items = is_array($items) ? $items : array();
    if ( count($items) > 5000 ) { return new WP_Error('grb_too_many_rows','Max 5000 rows per request', array('status'=>413)); }
    $fallback_lock = self::acquire_option_lock('grb_queue_sync_lock', 5 * MINUTE_IN_SECONDS);
    if ( $fallback_lock === false ) { return new WP_Error('grb_queue_busy','Queue sync is already running. Please retry in a moment.', array('status'=>409)); }
    try {
    $allowed = array('smart','append','replace','mirror');
    $mode = in_array($mode, $allowed, true) ? $mode : 'smart';

    $stats = array('mode'=>$mode,'received'=>count($items),'accepted'=>0,'added'=>0,'updated'=>0,'removed'=>0,'invalid'=>0,'duplicatesInCsv'=>0,'duplicatesInQueue'=>0,'skippedPublished'=>0,'queueCount'=>0);
    $published = $skip_published ? self::published_keys() : array();
    $skipped_keys = array();
    $mark_skipped = function($key) use (&$stats, &$skipped_keys){
      if ( ! isset($skipped_keys[$key]) ) { $skipped_keys[$key] = true; $stats['skippedPublished']++; }
    };

    $deduped = array(); $order = array();
    foreach ($items as $row){
      if ( ! is_array($row) ) { $stats['invalid']++; continue; }
      $row = self::sanitize_row($row);
      $key = self::row_key($row);
      if ( $key === '' ) { $stats['invalid']++; continue; }
      if ( isset($deduped[$key]) ) { $stats['duplicatesInCsv']++; }
      else { $order[] = $key; }
      $deduped[$key] = $row;
    }

    $queue = array(); $index = array(); $original_keys = array();
    foreach ( self::queue() as $row ){
      $row = self::sanitize_row(is_array($row) ? $row : array());
      $key = self::row_key($row);
      if ( $key === '' ) { continue; }
      if ( isset($original_keys[$key]) ) { $stats['duplicatesInQueue']++; continue; }
      $original_keys[$key] = true;
      if ( $skip_published && isset($published[$key]) ) { $mark_skipped($key); continue; }
      $index[$key] = count($queue);
      $queue[] = $row;
    }

    $new_queue = $queue;
    if ( $mode === 'replace' || $mode === 'mirror' ){
      $new_queue = array();
      foreach ($order as $key){
        if ( $skip_published && isset($published[$key]) ) { $mark_skipped($key); continue; }
        $new_queue[] = $deduped[$key];
        if ( isset($original_keys[$key]) ) { $stats['updated']++; } else { $stats['added']++; }
      }
    } elseif ( $mode === 'append' ){
      foreach ($order as $key){
        if ( $skip_published && isset($published[$key]) ) { $mark_skipped($key); continue; }
        if ( isset($index[$key]) ) { continue; }
        $new_queue[] = $deduped[$key]; $index[$key] = count($new_queue)-1; $stats['added']++;
      }
    } else {
      foreach ($order as $key){
        if ( $skip_published && isset($published[$key]) ) { $mark_skipped($key); continue; }
        if ( isset($index[$key]) ) { $new_queue[$index[$key]] = $deduped[$key]; $stats['updated']++; continue; }
        $new_queue[] = $deduped[$key]; $index[$key] = count($new_queue)-1; $stats['added']++;
      }
    }

    $new_keys = array();
    foreach ($new_queue as $row) { $key = self::row_key($row); if ($key !== '') { $new_keys[$key] = true; } }
    $stats['removed'] = count(array_diff_key($original_keys, $new_keys));
    $stats['accepted'] = $stats['added'] + $stats['updated'];
    $stats['queueCount'] = count($new_queue);
    if ( $stats['queueCount'] > 5000 ) {
      return new WP_Error('grb_queue_limit','Queue would exceed the 5000-row safety limit. Use Mirror or Replace mode, or reduce the CSV.', array('status'=>413));
    }
    update_option('ppai_csv_queue', array_values($new_queue), false);
    update_option('ppai_last_csv_sync', array_merge($stats, array('time'=>current_time('mysql'), 'source'=>'dashboard-bridge-v5.6', 'queueHash'=>md5(wp_json_encode($new_queue)))), false);
    return $stats;
    } finally {
      self::release_option_lock('grb_queue_sync_lock', $fallback_lock);
    }
  }


  private static function plugin_admin_includes(){
    if ( ! function_exists('get_plugins') || ! function_exists('is_plugin_active') || ! function_exists('delete_plugins') ) {
      require_once ABSPATH . 'wp-admin/includes/plugin.php';
    }
  }

  private static function plugin_upload_includes(){
    self::plugin_admin_includes();
    if ( ! function_exists('wp_tempnam') ) { require_once ABSPATH . 'wp-admin/includes/file.php'; }
    if ( ! class_exists('WP_Upgrader') || ! class_exists('Plugin_Upgrader') ) { require_once ABSPATH . 'wp-admin/includes/class-wp-upgrader.php'; }
    if ( ! class_exists('Automatic_Upgrader_Skin') && file_exists(ABSPATH . 'wp-admin/includes/class-wp-upgrader-skins.php') ) { require_once ABSPATH . 'wp-admin/includes/class-wp-upgrader-skins.php'; }
  }

  private static function protected_plugin_file(){
    return plugin_basename(__FILE__);
  }

  private static function is_protected_plugin( $plugin_file ){
    $plugin_file = (string) $plugin_file;
    if ( $plugin_file === self::protected_plugin_file() ) return true;
    return (bool) preg_match('#(^|/)sem-seo-bloger[^/]*/plugin\.php$#i', $plugin_file);
  }

  private static function sanitize_plugin_file( $plugin_file ){
    $plugin_file = trim((string) $plugin_file);
    $plugin_file = str_replace(array("\0", "\\"), array('', '/'), $plugin_file);
    $plugin_file = preg_replace('#/+#', '/', $plugin_file);
    $plugin_file = ltrim($plugin_file, '/');
    if ( $plugin_file === '' || strpos($plugin_file, '../') !== false || strpos($plugin_file, '..\\') !== false ) {
      return '';
    }
    return $plugin_file;
  }

  private static function plugin_summary_payload(){
    self::plugin_admin_includes();
    $plugins = get_plugins();
    $updates = get_site_transient('update_plugins');
    $items = array();
    $active_count = 0;
    $update_count = 0;

    foreach ( $plugins as $file => $data ) {
      $network_active = is_multisite() && is_plugin_active_for_network($file);
      $is_active = is_plugin_active($file) || $network_active;
      if ( $is_active ) { $active_count++; }
      $update_obj = ( is_object($updates) && isset($updates->response) && isset($updates->response[$file]) ) ? $updates->response[$file] : null;
      if ( $update_obj ) { $update_count++; }
      $items[] = array(
        'plugin' => $file,
        'name' => isset($data['Name']) ? wp_strip_all_tags($data['Name']) : $file,
        'version' => isset($data['Version']) ? (string) $data['Version'] : '',
        'description' => isset($data['Description']) ? wp_strip_all_tags($data['Description']) : '',
        'author' => isset($data['AuthorName']) && $data['AuthorName'] ? wp_strip_all_tags($data['AuthorName']) : ( isset($data['Author']) ? wp_strip_all_tags($data['Author']) : '' ),
        'pluginUri' => isset($data['PluginURI']) ? esc_url_raw($data['PluginURI']) : '',
        'active' => $is_active,
        'networkActive' => $network_active,
        'protected' => self::is_protected_plugin($file),
        'updateAvailable' => (bool) $update_obj,
        'updateVersion' => $update_obj && isset($update_obj->new_version) ? (string) $update_obj->new_version : '',
      );
    }

    usort($items, function($a, $b){ return strcasecmp((string) $a['name'], (string) $b['name']); });

    return array(
      'ok' => true,
      'site' => home_url(),
      'bridgeVersion' => GRB_BRIDGE_VER,
      'protectedPlugin' => self::protected_plugin_file(),
      'protectedPlugins' => array(self::protected_plugin_file(), 'sem-seo-bloger*/plugin.php'),
      'count' => count($items),
      'activeCount' => $active_count,
      'inactiveCount' => max(0, count($items) - $active_count),
      'updateCount' => $update_count,
      'plugins' => $items,
    );
  }

  private static function plugin_action_from_request( $request ){
    self::plugin_admin_includes();
    $p = $request->get_json_params();
    if ( ! is_array($p) ) { $p = array(); }
    $action = isset($p['action']) ? sanitize_key($p['action']) : '';
    $plugin_file = self::sanitize_plugin_file($p['plugin'] ?? '');
    $allowed = array('activate','deactivate','reactivate','delete');
    if ( ! in_array($action, $allowed, true) ) {
      return new WP_Error('grb_bad_plugin_action', 'Invalid plugin action.', array('status'=>400));
    }
    $plugins = get_plugins();
    if ( $plugin_file === '' || ! isset($plugins[$plugin_file]) ) {
      return new WP_Error('grb_plugin_not_found', 'Plugin not found.', array('status'=>404));
    }
    if ( self::is_protected_plugin($plugin_file) && in_array($action, array('deactivate','reactivate','delete'), true) ) {
      return new WP_Error('grb_plugin_protected', 'Core AutoBlog plugins are protected so the dashboard cannot disable publishing or its own connection.', array('status'=>400));
    }

    $result = true;
    if ( $action === 'activate' ) {
      $result = activate_plugin($plugin_file, '', false, false);
    } elseif ( $action === 'deactivate' ) {
      deactivate_plugins($plugin_file, false, false);
      $result = true;
    } elseif ( $action === 'reactivate' ) {
      deactivate_plugins($plugin_file, false, false);
      $result = activate_plugin($plugin_file, '', false, false);
    } elseif ( $action === 'delete' ) {
      if ( is_plugin_active($plugin_file) || ( is_multisite() && is_plugin_active_for_network($plugin_file) ) ) {
        if ( empty($p['forceDeactivate']) ) {
          return new WP_Error('grb_plugin_active', 'Plugin is active. Send forceDeactivate=true to deactivate before delete.', array('status'=>400));
        }
        deactivate_plugins($plugin_file, false, false);
      }
      $result = delete_plugins(array($plugin_file));
    }

    if ( is_wp_error($result) ) { return $result; }
    if ( $result === false ) {
      return new WP_Error('grb_plugin_action_failed', 'Plugin action failed.', array('status'=>500));
    }
    $payload = self::plugin_summary_payload();
    $payload['changedPlugin'] = $plugin_file;
    $payload['action'] = $action;
    return $payload;
  }

  private static function upload_plugin_from_request( $request ){
    self::plugin_upload_includes();
    $p = $request->get_json_params();
    if ( ! is_array($p) ) { $p = array(); }
    $filename = sanitize_file_name((string)($p['filename'] ?? 'plugin.zip'));
    if ( $filename === '' || substr(strtolower($filename), -4) !== '.zip' ) {
      return new WP_Error('grb_bad_plugin_zip', 'Only .zip plugin uploads are allowed.', array('status'=>400));
    }
    $encoded = (string)($p['contentBase64'] ?? '');
    if ( strpos($encoded, ',') !== false ) { $encoded = substr($encoded, strpos($encoded, ',') + 1); }
    $encoded = preg_replace('/\s+/', '', $encoded);
    if ( $encoded === '' ) {
      return new WP_Error('grb_empty_plugin_zip', 'Plugin ZIP content is empty.', array('status'=>400));
    }
    if ( strlen($encoded) > 90 * 1024 * 1024 ) {
      return new WP_Error('grb_plugin_zip_too_large', 'Plugin upload is too large for this bridge. Keep the ZIP under about 60 MB.', array('status'=>413));
    }
    $binary = base64_decode($encoded, true);
    if ( $binary === false || strlen($binary) < 22 ) {
      return new WP_Error('grb_bad_plugin_zip_data', 'Invalid base64 plugin ZIP data.', array('status'=>400));
    }
    if ( substr($binary, 0, 2) !== 'PK' ) {
      return new WP_Error('grb_not_zip', 'Uploaded file is not a valid ZIP archive.', array('status'=>400));
    }

    $tmp = wp_tempnam($filename);
    if ( ! $tmp ) {
      return new WP_Error('grb_tmp_failed', 'Unable to create temporary upload file.', array('status'=>500));
    }
    if ( false === file_put_contents($tmp, $binary) ) {
      @unlink($tmp);
      return new WP_Error('grb_tmp_write_failed', 'Unable to write temporary plugin ZIP.', array('status'=>500));
    }

    $skin = new Automatic_Upgrader_Skin();
    $upgrader = new Plugin_Upgrader($skin);
    $result = $upgrader->install($tmp, array('overwrite_package' => true));
    @unlink($tmp);

    if ( is_wp_error($result) ) { return $result; }
    if ( ! $result ) {
      $errors = method_exists($skin, 'get_errors') ? $skin->get_errors() : null;
      if ( is_wp_error($errors) && $errors->has_errors() ) { return $errors; }
      return new WP_Error('grb_plugin_install_failed', 'Plugin install failed. WordPress could not unpack or install the ZIP.', array('status'=>500));
    }

    $plugin_file = method_exists($upgrader, 'plugin_info') ? $upgrader->plugin_info() : '';
    $activated = false;
    if ( ! empty($p['activate']) && $plugin_file ) {
      $activate_result = activate_plugin($plugin_file, '', false, false);
      if ( is_wp_error($activate_result) ) { return $activate_result; }
      $activated = true;
    }

    $payload = self::plugin_summary_payload();
    $payload['uploaded'] = true;
    $payload['installedPlugin'] = $plugin_file;
    $payload['activated'] = $activated;
    $payload['filename'] = $filename;
    return $payload;
  }

  public static function register(){
    register_rest_route('grb/v1','/ping', array(
      'methods' => array('GET','POST'),
      'permission_callback' => array(__CLASS__, 'permission'),
      'callback' => function($req){
        $auth = self::auth_or_error($req); if ( is_wp_error($auth) ) { return $auth; }
        return array('ok'=>true,'bridgeVersion'=>GRB_BRIDGE_VER,'pluginActive'=>function_exists('ppai_run_auto_post'),'site'=>home_url());
      }
    ));

    register_rest_route('grb/v1','/diagnostics', array(
      'methods' => 'GET',
      'permission_callback' => array(__CLASS__, 'permission'),
      'callback' => function($req){
        $auth = self::auth_or_error($req); if ( is_wp_error($auth) ) { return $auth; }
        return array_merge(self::settings_payload(), array(
          'restOk' => true,
          'phpVersion' => PHP_VERSION,
          'wpVersion' => get_bloginfo('version'),
          'queueOptionType' => gettype(get_option('ppai_csv_queue', array())),
          'historyOptionType' => gettype(get_option('ppai_post_history', array())),
          'categoryRuntimeReady' => function_exists('term_exists') && function_exists('wp_insert_term'),
          'publisherRuntimeReady' => function_exists('ppai_run_auto_post') && function_exists('wp_insert_post'),
          'resolvedGeminiModel' => self::resolved_gemini_model(get_option('ppai_gemini_model','')),
          'semPluginVersion' => defined('PPAI_PLUGIN_VER') ? PPAI_PLUGIN_VER : ''
        ));
      }
    ));

    register_rest_route('grb/v1','/status', array(
      'methods' => 'GET',
      'permission_callback' => array(__CLASS__, 'permission'),
      'callback' => function($req){
        $auth = self::auth_or_error($req); if ( is_wp_error($auth) ) { return $auth; }
        $history = get_option('ppai_post_history', array());
        if ( ! is_array($history) ) { $history = array(); }
        $history = array_slice($history, -50);
        return array(
          'ok' => true,
          'queueCount'=> count(self::queue()),
          'lastError'=> self::redact_secret_text(get_option('ppai_last_error', '')),
          'history'=> array_values($history),
          'cronEnabled'=> (bool) wp_next_scheduled('ppai_auto_post_event')
        );
      }
    ));


    register_rest_route('grb/v1','/history', array(
      'methods' => 'GET',
      'permission_callback' => array(__CLASS__, 'permission'),
      'callback' => function($req){
        $auth = self::auth_or_error($req); if ( is_wp_error($auth) ) { return $auth; }
        return self::history_payload($req->get_param('limit'));
      }
    ));


    register_rest_route('grb/v1','/prompt', array(
      'methods' => array('GET','POST'),
      'permission_callback' => array(__CLASS__, 'permission'),
      'callback' => function($req){
        $auth = self::auth_or_error($req); if ( is_wp_error($auth) ) { return $auth; }
        if ( strtoupper($req->get_method()) === 'POST' ) {
          $updated = self::update_prompt_from_request($req);
          if ( is_wp_error($updated) ) { return $updated; }
          return $updated;
        }
        return self::prompt_payload($req->get_param('previewTopic'), $req->get_param('previewKeyword'));
      }
    ));


    register_rest_route('grb/v1','/prompt/generate', array(
      'methods' => 'POST',
      'permission_callback' => array(__CLASS__, 'permission'),
      'callback' => function($req){
        $auth = self::auth_or_error($req); if ( is_wp_error($auth) ) { return $auth; }
        return self::generate_prompt_from_request($req);
      }
    ));

    register_rest_route('grb/v1','/settings/test-gemini', array(
      'methods' => 'POST',
      'permission_callback' => array(__CLASS__, 'permission'),
      'callback' => function($req){
        $auth = self::auth_or_error($req); if ( is_wp_error($auth) ) { return $auth; }
        return self::test_gemini_key($req);
      }
    ));

    register_rest_route('grb/v1','/settings', array(
      'methods' => array('GET','POST'),
      'permission_callback' => array(__CLASS__, 'permission'),
      'callback' => function($req){
        $auth = self::auth_or_error($req); if ( is_wp_error($auth) ) { return $auth; }
        if ( strtoupper($req->get_method()) === 'POST' ) {
          $updated = self::update_settings_from_request($req);
          if ( is_wp_error($updated) ) { return $updated; }
          return $updated;
        }
        return self::settings_payload();
      }
    ));

    register_rest_route('grb/v1','/run', array(
      'methods' => 'POST',
      'permission_callback' => array(__CLASS__, 'permission'),
      'callback' => function($req){
        $auth = self::auth_or_error($req); if ( is_wp_error($auth) ) { return $auth; }
        if ( ! function_exists('ppai_run_auto_post') ) { return new WP_Error('grb_missing','SEM SEO BLOGER plugin not active', array('status'=>500)); }

        $p = $req->get_json_params();
        if ( ! is_array($p) ) { $p = array(); }
        $request_id = substr(sanitize_text_field((string)($p['requestId'] ?? '')), 0, 200);
        if ( $request_id === '' ) { $request_id = function_exists('wp_generate_uuid4') ? wp_generate_uuid4() : uniqid('grb_', true); }
        $hash = md5($request_id);
        $result_key = 'grb_run_result_' . $hash;
        $lock_key = 'grb_run_lock_' . $hash;
        $cached = get_transient($result_key);
        if ( is_array($cached) ) {
          return array_merge($cached, array('requestId'=>$request_id, 'idempotentReplay'=>true));
        }

        $lock_token = self::acquire_option_lock($lock_key, 15 * MINUTE_IN_SECONDS);
        if ( $lock_token === false ) {
          return array(
            'ok'=>true,
            'message'=>'This run request is already in progress.',
            'result'=>array('status'=>'skipped','message'=>'Same request is already running; no duplicate post was started.'),
            'requestId'=>$request_id,
            'idempotentReplay'=>true,
            'queueCount'=>count(self::queue())
          );
        }

        $ob_level = ob_get_level();
        try {
          ob_start();
          $res = ppai_run_auto_post();
          $echo = ob_get_clean();
          $echo = substr(trim(wp_strip_all_tags((string)$echo)), 0, 1000);
          if ( is_wp_error($res) ) {
            return new WP_Error('grb_run_failed', $res->get_error_message(), array('status'=>500));
          }
          $history = get_option('ppai_post_history', array());
          $last = is_array($history) && count($history) ? end($history) : null;
          $response = array('ok'=>true,'message'=>'Run completed','result'=>$res,'historyLast'=>$last,'echo'=>$echo,'queueCount'=>count(self::queue()),'requestId'=>$request_id);
          set_transient($result_key, $response, 6 * HOUR_IN_SECONDS);
          return $response;
        } catch ( Throwable $e ) {
          while ( ob_get_level() > $ob_level ) { ob_end_clean(); }
          return new WP_Error('grb_run_exception', $e->getMessage(), array('status'=>500));
        } finally {
          self::release_option_lock($lock_key, $lock_token);
        }
      }
    ));

    register_rest_route('grb/v1','/queue', array(
      'methods' => 'GET',
      'permission_callback' => array(__CLASS__, 'permission'),
      'callback' => function($req){
        $auth = self::auth_or_error($req); if ( is_wp_error($auth) ) { return $auth; }
        return array('ok'=>true,'items'=> self::queue(), 'queueCount'=>count(self::queue()), 'lastCsvSync'=>get_option('ppai_last_csv_sync', array()));
      }
    ));


    register_rest_route('grb/v1','/queue/sync', array(
      'methods' => 'POST',
      'permission_callback' => array(__CLASS__, 'permission'),
      'callback' => function($req){
        $auth = self::auth_or_error($req); if ( is_wp_error($auth) ) { return $auth; }
        $p = $req->get_json_params();
        if ( ! is_array($p) ) { $p = array(); }
        $items = isset($p['items']) && is_array($p['items']) ? $p['items'] : array();
        $mode = isset($p['mode']) ? sanitize_key($p['mode']) : 'smart';
        $skip = array_key_exists('skipPublished', $p) ? (bool) $p['skipPublished'] : false;
        $sync = self::sync_queue($items, $mode, $skip);
        if ( is_wp_error($sync) ) { return $sync; }
        return array_merge(array('ok'=>true), $sync);
      }
    ));

    register_rest_route('grb/v1','/queue/append', array(
      'methods' => 'POST',
      'permission_callback' => array(__CLASS__, 'permission'),
      'callback' => function($req){
        $auth = self::auth_or_error($req); if ( is_wp_error($auth) ) { return $auth; }
        $p = $req->get_json_params();
        if ( ! is_array($p) ) { $p = array(); }
        $items = isset($p['items']) && is_array($p['items']) ? $p['items'] : array();
        if ( count($items) > 5000 ) { return new WP_Error('grb_too_many_rows','Max 5000 rows per request', array('status'=>413)); }
        $sync = self::sync_queue($items, 'append', false);
        if ( is_wp_error($sync) ) { return $sync; }
        return array_merge(array('ok'=>true), $sync);
      }
    ));

    register_rest_route('grb/v1','/queue/clear', array(
      'methods' => 'POST',
      'permission_callback' => array(__CLASS__, 'permission'),
      'callback' => function($req){
        $auth = self::auth_or_error($req); if ( is_wp_error($auth) ) { return $auth; }
        $use_ppai_queue_lock = function_exists('ppai_acquire_queue_lock') && function_exists('ppai_release_queue_lock');
        $queue_lock = $use_ppai_queue_lock ? ppai_acquire_queue_lock(30) : self::acquire_option_lock('grb_queue_clear_lock', 30);
        if ( $queue_lock === false ) { return new WP_Error('grb_queue_busy', 'Queue is busy. Please retry in a moment.', array('status'=>409)); }
        try {
          update_option('ppai_csv_queue', array(), false);
        } finally {
          if ( $use_ppai_queue_lock ) ppai_release_queue_lock($queue_lock);
          else self::release_option_lock('grb_queue_clear_lock', $queue_lock);
        }
        return array('ok'=>true,'queueCount'=>0);
      }
    ));


    register_rest_route('grb/v1','/plugins', array(
      'methods' => 'GET',
      'permission_callback' => array(__CLASS__, 'permission'),
      'callback' => function($req){
        $auth = self::auth_or_error($req); if ( is_wp_error($auth) ) { return $auth; }
        return self::plugin_summary_payload();
      }
    ));

    register_rest_route('grb/v1','/plugins/action', array(
      'methods' => 'POST',
      'permission_callback' => array(__CLASS__, 'permission'),
      'callback' => function($req){
        $auth = self::auth_or_error($req); if ( is_wp_error($auth) ) { return $auth; }
        return self::plugin_action_from_request($req);
      }
    ));

    register_rest_route('grb/v1','/plugins/upload', array(
      'methods' => 'POST',
      'permission_callback' => array(__CLASS__, 'permission'),
      'callback' => function($req){
        $auth = self::auth_or_error($req); if ( is_wp_error($auth) ) { return $auth; }
        return self::upload_plugin_from_request($req);
      }
    ));

  }
}
add_action('rest_api_init', array('GRB_Bridge_Rest','register'));
